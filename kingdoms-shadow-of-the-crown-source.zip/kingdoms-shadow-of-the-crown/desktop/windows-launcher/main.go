package main

import (
	"context"
	"embed"
	"errors"
	"flag"
	"fmt"
	"io/fs"
	"net"
	"net/http"
	"os"
	"os/exec"
	"os/signal"
	"runtime"
	"syscall"
	"time"
)

// The release build copies the complete browser game into this folder.
//
//go:embed web
var embeddedGame embed.FS

type noCacheHandler struct {
	next http.Handler
}

func (handler noCacheHandler) ServeHTTP(writer http.ResponseWriter, request *http.Request) {
	writer.Header().Set("Cache-Control", "no-store")
	writer.Header().Set("X-Content-Type-Options", "nosniff")
	handler.next.ServeHTTP(writer, request)
}

func openBrowser(url string) error {
	var command *exec.Cmd
	switch runtime.GOOS {
	case "windows":
		command = exec.Command("rundll32.exe", "url.dll,FileProtocolHandler", url)
	case "darwin":
		command = exec.Command("open", url)
	default:
		command = exec.Command("xdg-open", url)
	}
	return command.Start()
}

func main() {
	noOpen := flag.Bool("no-open", false, "do not open the default browser")
	requestedPort := flag.Int("port", 0, "local port; 0 selects a free port")
	flag.Parse()

	gameFiles, err := fs.Sub(embeddedGame, "web")
	if err != nil {
		fatal("Cannot read the embedded game", err)
	}

	address := "127.0.0.1:0"
	if *requestedPort > 0 {
		address = fmt.Sprintf("127.0.0.1:%d", *requestedPort)
	}

	listener, err := net.Listen("tcp", address)
	if err != nil {
		fatal("Cannot start the local game server", err)
	}

	port := listener.Addr().(*net.TCPAddr).Port
	gameURL := fmt.Sprintf("http://localhost:%d/", port)
	server := &http.Server{
		Handler:           noCacheHandler{next: http.FileServer(http.FS(gameFiles))},
		ReadHeaderTimeout: 5 * time.Second,
	}

	fmt.Println("Kingdoms: Shadow of the Crown")
	fmt.Println("Game is running at:", gameURL)
	fmt.Println("Keep this window open while playing. Press Ctrl+C to stop.")

	serverErrors := make(chan error, 1)
	go func() {
		serverErrors <- server.Serve(listener)
	}()

	if !*noOpen {
		if err := openBrowser(gameURL); err != nil {
			fmt.Println("The browser did not open automatically.")
			fmt.Println("Open this address manually:", gameURL)
		}
	}

	stop := make(chan os.Signal, 1)
	signal.Notify(stop, os.Interrupt, syscall.SIGTERM)

	select {
	case <-stop:
		fmt.Println("Stopping the game...")
	case err := <-serverErrors:
		if err != nil && !errors.Is(err, http.ErrServerClosed) {
			fatal("The local game server stopped unexpectedly", err)
		}
	}

	ctx, cancel := context.WithTimeout(context.Background(), 2*time.Second)
	defer cancel()
	_ = server.Shutdown(ctx)
}

func fatal(message string, err error) {
	fmt.Fprintln(os.Stderr, message+":", err)
	fmt.Fprintln(os.Stderr, "Press Enter to close this window.")
	_, _ = fmt.Scanln()
	os.Exit(1)
}
