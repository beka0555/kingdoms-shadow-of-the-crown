# Third-party notices

This project includes **Three.js r169** (`vendor/three.module.js`).  
Copyright © 2010–2024 three.js authors. SPDX-License-Identifier: MIT.  
Source: <https://github.com/mrdoob/three.js>

Gesture control loads **MediaPipe Tasks Vision / Hand Landmarker** on demand from the jsDelivr CDN and the official Google model storage.  
Copyright Google LLC. SPDX-License-Identifier: Apache-2.0.  
Source: <https://github.com/google-ai-edge/mediapipe>

The interface requests **Cormorant Garamond** and **Inter** from Google Fonts. Both font families are distributed under the SIL Open Font License 1.1.
