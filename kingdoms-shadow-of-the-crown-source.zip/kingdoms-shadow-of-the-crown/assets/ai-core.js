export function scoreNeighborTactics(faction,state,counts){
  const hostility=Math.max(0,-faction.relation),friendship=Math.max(0,faction.relation),weakArmy=Math.max(0,75-state.army),rich=Math.max(0,state.treasury-120),lowFood=Math.max(0,65-state.food);
  return {
    trade:friendship*.8+lowFood*.25+(faction.bias==='trade'?22:0),
    alliance:friendship+(counts.diplomacy||0)*12+(faction.bias==='trade'?8:0),
    spy:rich*.18+(counts.economy||0)*17+hostility*.25,
    raid:weakArmy*.55+(counts.economy||0)*10+hostility*.45+(faction.bias==='raid'?20:0),
    siege:weakArmy*.7+hostility*.65-(counts.diplomacy||0)*4+(faction.bias==='military'?20:0)
  };
}

export function chooseNeighborStrategy(faction,state,counts){
  const scores=scoreNeighborTactics(faction,state,counts),tactic=Object.entries(scores).sort((a,b)=>b[1]-a[1])[0][0];
  const labels={trade:'торговое предложение',alliance:'предложение союза',spy:'шпионская операция',raid:'пограничный рейд',siege:'подготовка осады'};
  const reasons={trade:'вашему королевству нужны ресурсы',alliance:'дипломатия повысила доверие',spy:'частые вложения в экономику привлекли разведку',raid:'сосед заметил недостаток военной силы',siege:'враждебность и слабая армия сделали атаку выгодной'};
  return {tactic,label:labels[tactic],reason:reasons[tactic],score:scores[tactic],scores};
}

export function classifyFingerState({index=false,middle=false,ring=false,pinky=false,dx=0,dy=0}){
  const extended=[index,middle,ring,pinky].filter(Boolean).length;
  if(extended>=4)return {gesture:'palm',action:'block',label:'Ладонь: блок'};
  if(extended===0)return {gesture:'fist',action:'attack',label:'Кулак: удар'};
  if(index&&middle&&!ring&&!pinky)return {gesture:'two-fingers',action:'interact',label:'Два пальца: действие'};
  if(index&&!middle&&!ring&&!pinky){
    if(Math.abs(dx)>Math.abs(dy)*.72)return {gesture:'point',action:dx>0?'right':'left',label:dx>0?'Указатель: вправо':'Указатель: влево'};
    return {gesture:'point',action:dy>.06?'forward':'backward',label:dy>.06?'Указатель: вперёд':'Указатель: назад'};
  }
  return {gesture:'unknown',action:'none',label:'Жест не распознан'};
}

export function guardScenario({state='patrol',sees=false,heard=false,alert=0,lostSeconds=0}){
  if(sees&&alert>=72)return 'chase';
  if(sees||heard)return 'investigate';
  if(state==='chase'&&lostSeconds<=5)return 'chase';
  if(state==='chase'&&lostSeconds>5)return 'investigate';
  return 'patrol';
}
