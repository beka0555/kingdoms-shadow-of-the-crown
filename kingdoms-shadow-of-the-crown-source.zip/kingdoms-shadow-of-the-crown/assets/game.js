import * as THREE from '../vendor/three.module.js';
import {chooseNeighborStrategy,classifyFingerState} from './ai-core.js';

const $=q=>document.querySelector(q),$$=q=>[...document.querySelectorAll(q)];
const clamp=(n,a,b)=>Math.max(a,Math.min(b,n)),rand=(a,b)=>a+Math.random()*(b-a);
const canvas=$('#world');
const renderer=new THREE.WebGLRenderer({canvas,antialias:true,powerPreference:'high-performance'});
renderer.setPixelRatio(Math.min(devicePixelRatio,1.6));renderer.shadowMap.enabled=true;renderer.shadowMap.type=THREE.PCFSoftShadowMap;renderer.outputColorSpace=THREE.SRGBColorSpace;renderer.toneMapping=THREE.ACESFilmicToneMapping;renderer.toneMappingExposure=1.18;
const scene=new THREE.Scene();scene.background=new THREE.Color(0x0a171c);scene.fog=new THREE.FogExp2(0x102126,.0065);
const camera=new THREE.PerspectiveCamera(67,1,.08,520);scene.add(new THREE.HemisphereLight(0x76929a,0x10130e,1.85));
const moon=new THREE.DirectionalLight(0x9fb8cf,2.1);moon.position.set(-70,110,55);moon.castShadow=true;moon.shadow.mapSize.set(2048,2048);moon.shadow.camera.left=-210;moon.shadow.camera.right=210;moon.shadow.camera.top=210;moon.shadow.camera.bottom=-210;scene.add(moon);
const world=new THREE.Group();scene.add(world);

const mats={
  ground:new THREE.MeshStandardMaterial({color:0x27372d,roughness:1}),grass:new THREE.MeshStandardMaterial({color:0x203426,roughness:1}),
  stone:new THREE.MeshStandardMaterial({color:0x555b58,roughness:.95}),stoneDark:new THREE.MeshStandardMaterial({color:0x303735,roughness:1}),
  roof:new THREE.MeshStandardMaterial({color:0x3a2423,roughness:.85}),wood:new THREE.MeshStandardMaterial({color:0x493526,roughness:.9}),
  iron:new THREE.MeshStandardMaterial({color:0x24292a,metalness:.65,roughness:.5}),gold:new THREE.MeshStandardMaterial({color:0xd1a448,metalness:.75,roughness:.28}),
  red:new THREE.MeshStandardMaterial({color:0x6e2727,roughness:.8}),cloth:new THREE.MeshStandardMaterial({color:0x182e3b,roughness:.9}),skin:new THREE.MeshStandardMaterial({color:0xa88667,roughness:1}),
  bush:new THREE.MeshStandardMaterial({color:0x183b26,roughness:1}),paper:new THREE.MeshStandardMaterial({color:0xc1ad7f,roughness:1}),water:new THREE.MeshPhysicalMaterial({color:0x1a4248,roughness:.2,transparent:true,opacity:.7})
};
const colliders=[],occluders=[],bushes=[],guards=[],interactables=[],worldInteractions=[],torches=[];
function addMesh(geo,mat,x=0,y=0,z=0,shadow=true,parent=world){const m=new THREE.Mesh(geo,mat);m.position.set(x,y,z);m.castShadow=shadow;m.receiveShadow=true;parent.add(m);return m}
function box(x,y,z,w,h,d,mat=mats.stone,solid=true){const m=addMesh(new THREE.BoxGeometry(w,h,d),mat,x,y+h/2,z);if(solid){colliders.push({minX:x-w/2,maxX:x+w/2,minZ:z-d/2,maxZ:z+d/2});occluders.push(m)}return m}
function cylinder(x,y,z,r,h,mat=mats.stone,solid=true){const m=addMesh(new THREE.CylinderGeometry(r,r*1.06,h,12),mat,x,y+h/2,z);if(solid){colliders.push({minX:x-r,maxX:x+r,minZ:z-r,maxZ:z+r});occluders.push(m)}return m}
function battlements(x,z,length,axis='x',height=9){for(let i=-length/2+1;i<length/2;i+=3){const bx=axis==='x'?x+i:x,bz=axis==='z'?z+i:z;box(bx,height,bz,1.45,1.2,1.25,mats.stoneDark,false)}}

// Ground, paths, river and nocturnal atmosphere.
const ground=addMesh(new THREE.PlaneGeometry(440,440),mats.ground,0,-.1,-50);ground.rotation.x=-Math.PI/2;
const path=addMesh(new THREE.PlaneGeometry(10,66),new THREE.MeshStandardMaterial({color:0x4a4437,roughness:1}),0,.01,48);path.rotation.x=-Math.PI/2;
const moat=addMesh(new THREE.RingGeometry(37,42,4,1),mats.water,0,.03,0);moat.rotation.x=-Math.PI/2;moat.rotation.z=Math.PI/4;
const starsGeo=new THREE.BufferGeometry(),starPos=[];for(let i=0;i<450;i++){const a=rand(0,Math.PI*2),r=rand(75,150),y=rand(45,100);starPos.push(Math.cos(a)*r,y,Math.sin(a)*r)}starsGeo.setAttribute('position',new THREE.Float32BufferAttribute(starPos,3));scene.add(new THREE.Points(starsGeo,new THREE.PointsMaterial({color:0xc5d5dd,size:.35,transparent:true,opacity:.65})));
const rainGeo=new THREE.BufferGeometry(),rainPos=[];for(let i=0;i<1500;i++)rainPos.push(rand(-210,210),rand(2,55),rand(-250,180));rainGeo.setAttribute('position',new THREE.Float32BufferAttribute(rainPos,3));const rain=new THREE.Points(rainGeo,new THREE.PointsMaterial({color:0x9eb6bd,size:.08,transparent:true,opacity:.42}));scene.add(rain);

function tree(x,z,s=1){addMesh(new THREE.CylinderGeometry(.35*s,.5*s,3.8*s,7),mats.wood,x,1.9*s,z);const c=addMesh(new THREE.ConeGeometry(2.2*s,6*s,8),new THREE.MeshStandardMaterial({color:Math.random()>.5?0x183222:0x203a29,roughness:1}),x,5.3*s,z);c.rotation.y=rand(0,6)}
for(let i=0;i<90;i++){let x=rand(-78,78),z=rand(-78,78);if(Math.abs(x)<46&&Math.abs(z)<46||Math.abs(x)<9&&z>25){i--;continue}tree(x,z,rand(.7,1.25))}
function bush(x,z,s=1){const g=new THREE.Group();for(let i=0;i<5;i++){const m=new THREE.Mesh(new THREE.DodecahedronGeometry(rand(.8,1.25)*s,0),mats.bush);m.position.set(rand(-1,1)*s,rand(.6,1.1)*s,rand(-.8,.8)*s);m.castShadow=true;g.add(m)}g.position.set(x,0,z);world.add(g);bushes.push({x,z,r:2.4*s})}
[[-8,44],[10,42],[-24,38],[25,46],[-38,7],[-36,-2],[37,15],[-22,22],[23,21],[7,25]].forEach(p=>bush(p[0],p[1],1.2));

// Castle walls: the southern gate and western breach are physically traversable.
box(-18,0,30,24,9,3);box(18,0,30,24,9,3);battlements(-18,30,24);battlements(18,30,24);
box(0,0,-30,60,9,3);battlements(0,-30,60);
box(-30,0,-17.6,3,9,24.8);box(-30,0,13.6,3,9,32.8);battlements(-30,-17.6,24.8,'z');battlements(-30,13.6,32.8,'z');
box(30,0,0,3,9,60);battlements(30,0,60,'z');
for(const [x,z] of [[-30,-30],[30,-30],[-30,30],[30,30]]){cylinder(x,0,z,5,13);for(let i=0;i<8;i++){const a=i*Math.PI/4;box(x+Math.sin(a)*4,13,z+Math.cos(a)*4,1.6,1.3,1.4,mats.stoneDark,false)}}
// Gatehouse and raised portcullis.
box(-6,0,28,4,13,7);box(6,0,28,4,13,7);box(0,9.5,29,8,3,4,mats.stoneDark,false);for(let x=-3.2;x<=3.2;x+=1.05)box(x,7.8,29,.16,5,.25,mats.iron,false);
// Bridge across the moat.
for(let z=31;z<43;z+=1.5)box(0,.04,z,8,.32,1.25,mats.wood,false);

function torch(x,z,y=3){const pole=addMesh(new THREE.CylinderGeometry(.06,.08,y,6),mats.iron,x,y/2,z);const flame=addMesh(new THREE.SphereGeometry(.18,7,6),new THREE.MeshBasicMaterial({color:0xffb044}),x,y+.2,z,false);const light=new THREE.PointLight(0xff7b32,4.5,12,2);light.position.set(x,y+.2,z);world.add(light);torches.push({flame,light,phase:rand(0,10)})}
[[-6,25],[6,25],[-24,25],[24,25],[-25,-5],[25,-5],[-12,-7],[12,-7],[-20,-24],[20,-24]].forEach(p=>torch(...p));

// Walkable buildings with actual interiors and door gaps.
function room(cx,cz,w,d,h,door='south',mat=mats.stoneDark){
  const t=1;
  box(cx,0,cz-d/2,w,h,t,mat);box(cx,0,cz+d/2,(w-3)/2,h,t,mat);box(cx-w/2/2-1.5/2,0,cz+d/2,(w-3)/2,h,t,mat); // overwritten below for door clarity
  // Remove the accidental center pattern by adding proper side/front walls; visual overlap is harmless.
  box(cx-w/2,0,cz,t,h,d,mat);box(cx+w/2,0,cz,t,h,d,mat);
  const roof=addMesh(new THREE.BoxGeometry(w+.5,.5,d+.5),mats.roof,cx,h,cz);roof.castShadow=true;
}
// Command room manual shell, doorway on south.
box(-15,0,-18,13,7,1,mats.stoneDark);box(-21.5,0,-13,1,7,10,mats.stoneDark);box(-8.5,0,-13,1,7,10,mats.stoneDark);box(-19,0,-8,5,7,1,mats.stoneDark);box(-11,0,-8,5,7,1,mats.stoneDark);addMesh(new THREE.BoxGeometry(14,.5,11),mats.roof,-15,7,-13);
const table=box(-15,0,-13,5,1.1,2.5,mats.wood,true);addMesh(new THREE.PlaneGeometry(2.4,1.5),mats.paper,-15,1.12,-13,false).rotation.x=-Math.PI/2;
// Treasury, doorway on south.
box(15,0,-20,13,7,1,mats.stoneDark);box(8.5,0,-14,1,7,12,mats.stoneDark);box(21.5,0,-14,1,7,12,mats.stoneDark);box(11,0,-8,5,7,1,mats.stoneDark);box(19,0,-8,5,7,1,mats.stoneDark);addMesh(new THREE.BoxGeometry(14,.5,13),mats.roof,15,7,-14);
function chest(x,z){const base=box(x,0,z,3,1.5,1.8,mats.wood,true);const lid=addMesh(new THREE.CylinderGeometry(.9,.9,3,16,1,false,0,Math.PI),mats.wood,x,1.5,z);lid.rotation.z=Math.PI/2;for(let i=0;i<9;i++){const coin=addMesh(new THREE.CylinderGeometry(.13,.13,.045,12),mats.gold,x+rand(-1,1),rand(.2,1.4),z+rand(-.55,.55));coin.rotation.x=Math.PI/2}return base}chest(15,-14);
// Keep, barracks and market stalls add believable density.
box(0,0,-5,10,15,13,mats.stone);battlements(0,-11,10);battlements(0,1,10);
for(const x of [-24,24]){box(x,0,10,7,4,12,mats.wood);const roof=addMesh(new THREE.ConeGeometry(7,4,4),mats.roof,x,6,10);roof.rotation.y=Math.PI/4}
for(let i=0;i<5;i++)box(-27+i*1.45,0,17,1.1,1+rand(0,.5),1.1,mats.wood,true);
for(let i=0;i<7;i++)box(21+i*.95,0,16.5,.1,3,.1,mats.iron,false);box(24,0,16.5,7,.12,.18,mats.iron,false);box(24,2.9,16.5,7,.12,.18,mats.iron,false);
for(const [x,z] of [[-8,16],[0,18],[9,15]]){box(x,0,z,5,2.4,4,mats.wood);const awning=addMesh(new THREE.BoxGeometry(6,.2,3),mats.red,x,2.8,z);awning.rotation.x=.12}

// A cramped crawlspace: the opening is deliberately small and only fits a crouched player.
box(-34,0,-5.9,8,2.2,1.4,mats.stoneDark);box(-34,0,-2.1,8,2.2,1.4,mats.stoneDark);addMesh(new THREE.BoxGeometry(9,.55,3.8),mats.stoneDark,-34,1.55,-4);
for(let i=0;i<16;i++){const r=addMesh(new THREE.DodecahedronGeometry(rand(.3,.72),0),mats.stone,-38+rand(-2,2),rand(.18,.6),-4+rand(-2.2,2.2));r.rotation.set(rand(0,2),rand(0,2),rand(0,2))}

// Horse and extraction point.
function horse(x,z){const g=new THREE.Group();const body=new THREE.Mesh(new THREE.CapsuleGeometry(.8,2.1,5,8),new THREE.MeshStandardMaterial({color:0x3b291e}));body.rotation.z=Math.PI/2;body.position.y=1.7;g.add(body);const neck=new THREE.Mesh(new THREE.CylinderGeometry(.32,.5,1.8,8),new THREE.MeshStandardMaterial({color:0x3b291e}));neck.position.set(1.25,2.35,0);neck.rotation.z=-.5;g.add(neck);const head=new THREE.Mesh(new THREE.BoxGeometry(.65,.55,.5),new THREE.MeshStandardMaterial({color:0x3b291e}));head.position.set(1.65,3.1,0);g.add(head);for(const lx of [-.7,.6])for(const lz of [-.42,.42]){const leg=new THREE.Mesh(new THREE.CylinderGeometry(.1,.13,1.6,6),mats.wood);leg.position.set(lx,.8,lz);g.add(leg)}g.position.set(x,0,z);g.rotation.y=-.2;world.add(g);return g}horse(5,59);

// Four connected territories: the original citadel, western frontier, eastern abbey town and royal capital.
function road(x,z,w,d,rotation=0){const r=addMesh(new THREE.PlaneGeometry(w,d),new THREE.MeshStandardMaterial({color:0x51483a,roughness:1}),x,.005,z,false);r.rotation.x=-Math.PI/2;r.rotation.z=rotation;return r}
road(-74,12,92,9,Math.PI/2);road(74,12,92,9,Math.PI/2);road(0,-72,9,78);road(0,-205,9,70);
function watchTower(x,z,r=4,h=12,mat=mats.stone){cylinder(x,0,z,r,h,mat);for(let i=0;i<8;i++){const a=i*Math.PI/4;box(x+Math.sin(a)*(r-.35),h,z+Math.cos(a)*(r-.35),1.15,1.25,1.15,mats.stoneDark,false)}return addMesh(new THREE.ConeGeometry(r+1,3.2,8),mats.roof,x,h+2,z)}
function banner(x,y,z,color=0x8d2e2e){const pole=addMesh(new THREE.CylinderGeometry(.045,.055,4,6),mats.iron,x,y+2,z);const cloth=addMesh(new THREE.PlaneGeometry(1.5,2.3),new THREE.MeshStandardMaterial({color,side:THREE.DoubleSide,roughness:.8}),x+.78,y+2.7,z);return {pole,cloth}}
function hut(x,z,w=7,d=6,color=mats.wood){box(x,0,z,w,3.8,d,color);const roof=addMesh(new THREE.ConeGeometry(Math.max(w,d)*.72,3.2,4),mats.roof,x,5.2,z);roof.rotation.y=Math.PI/4}

// Western frontier fortress: timber walls, six towers, barracks and a command yard.
box(-152,0,0,2.4,8,66,mats.wood);box(-120,0,-33,66,8,2.4,mats.wood);box(-120,0,33,66,8,2.4,mats.wood);box(-88,0,-18,2.4,8,30,mats.wood);box(-88,0,18,2.4,8,30,mats.wood);
for(const [x,z] of [[-152,-33],[-152,33],[-88,-33],[-88,33],[-120,-33],[-120,33]])watchTower(x,z,3.6,11,mats.wood);
hut(-132,-13,10,8);hut(-132,13,10,8);hut(-108,-13,10,8);hut(-108,13,10,8);box(-120,0,-4,16,8,13,mats.stoneDark);battlements(-120,-10,16);
for(const [x,z] of [[-144,-23],[-144,23],[-96,-23],[-96,23],[-120,25]])torch(x,z,4);banner(-90,4,-7,0x6f3423);banner(-90,4,7,0x6f3423);

// Eastern abbey town: stone enclosure, monastery, bell tower, well and storehouses.
box(152,0,0,2.6,9,68,mats.stoneDark);box(120,0,-34,66,9,2.6,mats.stoneDark);box(120,0,34,66,9,2.6,mats.stoneDark);box(88,0,-19,2.6,9,30,mats.stoneDark);box(88,0,19,2.6,9,30,mats.stoneDark);
for(const [x,z] of [[88,-34],[88,34],[152,-34],[152,34]])watchTower(x,z,4.2,14);
// Abbey shell with a western doorway.
box(126,0,-12,22,11,1,mats.stone);box(126,0,12,22,11,1,mats.stone);box(137,0,0,1,11,25,mats.stone);box(115,0,-7,1,11,10,mats.stone);box(115,0,7,1,11,10,mats.stone);addMesh(new THREE.BoxGeometry(23,.55,25),mats.roof,126,11,0);
watchTower(141,0,5,20);for(const [x,z] of [[103,-20],[103,20],[138,22]])hut(x,z,9,7,mats.stoneDark);
const abbeyWell=addMesh(new THREE.TorusGeometry(2,.45,8,20),mats.stone,112,.55,0);abbeyWell.rotation.x=Math.PI/2;for(const [x,z] of [[94,-25],[94,25],[145,-24],[145,24],[118,-8]])torch(x,z,4);
// The antidote sits on an accessible crate outside the solid storehouse wall.
box(132,0,22,1.8,.75,1.3,mats.wood,true);const antidoteVial=addMesh(new THREE.CylinderGeometry(.16,.2,.62,10),new THREE.MeshPhysicalMaterial({color:0x67c9a4,emissive:0x164f40,emissiveIntensity:1.2,transparent:true,opacity:.82,roughness:.14}),132,.95,22);addMesh(new THREE.CylinderGeometry(.11,.11,.16,8),mats.wood,132,1.34,22);

// Northern royal capital with a broad outer wall and many towers.
box(-20,0,-98,30,12,3,mats.stone);box(20,0,-98,30,12,3,mats.stone);box(0,0,-172,76,12,3,mats.stone);box(-38,0,-135,3,12,76,mats.stone);box(38,0,-135,3,12,76,mats.stone);
for(const [x,z] of [[-38,-98],[38,-98],[-38,-172],[38,-172],[-38,-135],[38,-135]])watchTower(x,z,5,17);
box(-6,0,-100,4,18,9,mats.stoneDark);box(6,0,-100,4,18,9,mats.stoneDark);box(0,14,-100,8,4,5,mats.stoneDark,false);banner(-8,11,-96);banner(8,11,-96);
// Royal houses, archive and guard barracks.
for(const [x,z] of [[-25,-116],[25,-116],[-25,-151],[25,-151],[-13,-112],[13,-112]])hut(x,z,9,8,mats.stoneDark);
box(-24,0,-135,14,7,16,mats.stoneDark);box(24,0,-135,14,7,16,mats.stoneDark);
// Enterable King's High Tower. Door is centered in the southern wall at z=-127.
box(0,0,-151,24,22,2,mats.stone);box(-12,0,-139,2,22,26,mats.stone);box(12,0,-139,2,22,26,mats.stone);box(-7.5,0,-127,9,22,2,mats.stone);box(7.5,0,-127,9,22,2,mats.stone);addMesh(new THREE.BoxGeometry(25,.7,27),mats.roof,0,22,-139);
for(const [x,z] of [[-11,-128],[11,-128],[-11,-150],[11,-150]])watchTower(x,z,2.7,26,mats.stoneDark);
const throne=box(0,0,-144,3.2,2.5,2.2,mats.gold,true);bodyPart(new THREE.BoxGeometry(3.2,4,.45),mats.red,throne,0,2.1,.8);for(let i=0;i<7;i++)box(-6+i*2,0,-132-i*1.45,12-i*1.1,.28,1.2,mats.stoneDark,false);
for(const [x,z] of [[-32,-105],[32,-105],[-30,-163],[30,-163],[-9,-126],[9,-126],[0,-148]])torch(x,z,5);

// Forest and roadside details between the regions.
for(let i=0;i<135;i++){const side=Math.random()<.5?-1:1,x=rand(48,205)*side,z=rand(-205,85);if((x<-82&&x>-158&&Math.abs(z)<40)||(x>82&&x<158&&Math.abs(z)<40)||(Math.abs(x)<45&&z<-92&&z>-178)){i--;continue}tree(x,z,rand(.65,1.15))}
for(const [x,z] of [[-70,13],[-52,15],[52,13],[70,10],[-8,-62],[8,-78],[0,-188],[-120,43],[120,43]]){box(x,0,z,2.4,1.1,1.4,mats.wood);}

// One continuous kingdom: a single outer border and dense districts between the strongholds.
box(-180,0,-55,3,7,245,mats.stoneDark);box(180,0,-55,3,7,245,mats.stoneDark);box(-102,0,68,153,7,3,mats.stoneDark);box(102,0,68,153,7,3,mats.stoneDark);box(-102,0,-198,153,7,3,mats.stoneDark);box(102,0,-198,153,7,3,mats.stoneDark);
for(const [x,z] of [[-180,68],[180,68],[-180,-198],[180,-198],[-180,-120],[180,-120],[-180,0],[180,0],[-120,68],[120,68],[-120,-198],[120,-198],[-40,-198],[40,-198]])watchTower(x,z,4.2,13,mats.stoneDark);
// Continuous residential streets connect every inner district.
for(const x of [-76,-62,-48,48,62,76]){hut(x,-4,7,6);hut(x,28,7,6);if(Math.abs(x)>50)hut(x,-22,6,6,mats.stoneDark)}
for(const z of [-48,-62,-76]){hut(-18,z,8,7,mats.stoneDark);hut(18,z,8,7,mats.stoneDark);hut(-31,z,6,6);hut(31,z,6,6)}
for(const x of [-165,-145,-95,-75,75,95,145,165]){hut(x,52,7,6);}
// Farms and work yards keep the large spaces readable instead of empty.
for(const [x,z] of [[-165,42],[-150,48],[-102,50],[102,50],[150,48],[165,42],[-68,-45],[68,-45],[-58,-82],[58,-82]]){const field=addMesh(new THREE.PlaneGeometry(12,8),new THREE.MeshStandardMaterial({color:0x4b4b2c,roughness:1}),x,.01,z,false);field.rotation.x=-Math.PI/2;for(let i=-4;i<=4;i+=2)box(x+i,0,z,.12,.45,7,mats.wood,false)}
for(const [x,z] of [[-82,4],[-64,4],[-46,4],[46,4],[64,4],[82,4],[-5,-48],[5,-64],[0,-82]])torch(x,z,3.5);

// Articulated human characters with separate torso, pelvis, limbs, hands and feet.
const humanMats={
  leather:new THREE.MeshStandardMaterial({color:0x4b3324,roughness:.88}),darkLeather:new THREE.MeshStandardMaterial({color:0x241c18,roughness:.92}),
  cloak:new THREE.MeshStandardMaterial({color:0x122a38,roughness:.92,side:THREE.DoubleSide}),steel:new THREE.MeshStandardMaterial({color:0x596165,metalness:.72,roughness:.42}),
  chain:new THREE.MeshStandardMaterial({color:0x3f4749,metalness:.55,roughness:.58}),guardCloth:new THREE.MeshStandardMaterial({color:0x7a2929,roughness:.82}),
  hair:new THREE.MeshStandardMaterial({color:0x171310,roughness:1}),eye:new THREE.MeshStandardMaterial({color:0xc8c5b5,roughness:.7}),pupil:new THREE.MeshStandardMaterial({color:0x11191b,roughness:.6})
};
const stylizedHeadGeometry=new THREE.LatheGeometry([new THREE.Vector2(.08,-.34),new THREE.Vector2(.23,-.29),new THREE.Vector2(.29,-.08),new THREE.Vector2(.285,.12),new THREE.Vector2(.23,.3),new THREE.Vector2(.1,.37)],18);
const spyTorsoGeometry=new THREE.LatheGeometry([new THREE.Vector2(.27,-.46),new THREE.Vector2(.35,-.34),new THREE.Vector2(.4,.22),new THREE.Vector2(.31,.5)],14);
const guardTorsoGeometry=new THREE.LatheGeometry([new THREE.Vector2(.31,-.45),new THREE.Vector2(.39,-.3),new THREE.Vector2(.43,.27),new THREE.Vector2(.34,.51)],14);
function bodyPart(geo,mat,parent,x,y,z,rx=0,ry=0,rz=0){const m=new THREE.Mesh(geo,mat);m.position.set(x,y,z);m.rotation.set(rx,ry,rz);m.castShadow=true;m.receiveShadow=true;parent.add(m);return m}
function makeLimb(parent,x,y,z,upperLen,lowerLen,mat,boot=false){
  const upper=new THREE.Group();upper.position.set(x,y,z);parent.add(upper);
  bodyPart(new THREE.CapsuleGeometry(.105,Math.max(.08,upperLen-.21),4,7),mat,upper,0,-upperLen/2,0);
  const lower=new THREE.Group();lower.position.y=-upperLen;upper.add(lower);bodyPart(new THREE.CapsuleGeometry(.095,Math.max(.08,lowerLen-.19),4,7),boot?humanMats.darkLeather:mat,lower,0,-lowerLen/2,0);
  const end=bodyPart(boot?new THREE.BoxGeometry(.22,.17,.4):new THREE.SphereGeometry(.12,8,6),boot?humanMats.darkLeather:mats.skin,lower,0,-lowerLen-.02,boot?-.09:0);return {upper,lower,end};
}
function poseRig(rig,phase=0,strength=0){
  const s=Math.sin(phase)*strength;rig.leftLeg.upper.rotation.x=s*.7;rig.rightLeg.upper.rotation.x=-s*.7;rig.leftLeg.lower.rotation.x=Math.max(0,-s)*.5;rig.rightLeg.lower.rotation.x=Math.max(0,s)*.5;
  rig.leftArm.upper.rotation.x=-s*.48;rig.rightArm.upper.rotation.x=s*.48;rig.leftArm.lower.rotation.x=-.12-Math.max(0,s)*.18;rig.rightArm.lower.rotation.x=-.12-Math.max(0,-s)*.18;if(rig.cloak)rig.cloak.rotation.x=.05+Math.abs(s)*.08;
}
function cloakGeometry(){const s=new THREE.Shape();s.moveTo(-.43,.66);s.lineTo(.43,.66);s.lineTo(.57,-.76);s.lineTo(.18,-.69);s.lineTo(0,-.82);s.lineTo(-.18,-.69);s.lineTo(-.57,-.76);s.closePath();return new THREE.ShapeGeometry(s)}
function createHuman(role='spy'){
  const g=new THREE.Group(),isGuard=role==='guard',cloth=isGuard?humanMats.guardCloth:mats.cloth;
  const pelvis=bodyPart(new THREE.BoxGeometry(.58,.3,.38),humanMats.darkLeather,g,0,.96,0);
  const torso=bodyPart(isGuard?guardTorsoGeometry:spyTorsoGeometry,isGuard?humanMats.chain:cloth,g,0,1.55,0);torso.scale.z=.72;
  bodyPart(new THREE.BoxGeometry(.9,.13,.5),isGuard?humanMats.steel:humanMats.leather,g,0,1.83,0);bodyPart(new THREE.BoxGeometry(.72,.11,.45),humanMats.darkLeather,g,0,1.12,0);
  bodyPart(new THREE.CylinderGeometry(.13,.15,.18,8),mats.skin,g,0,2.05,0);const head=bodyPart(stylizedHeadGeometry,mats.skin,g,0,2.31,0);head.scale.set(.9,1,.88);
  bodyPart(new THREE.ConeGeometry(.07,.17,8),mats.skin,g,0,2.31,-.285,-Math.PI/2,0,0);
  for(const ex of [-.105,.105]){bodyPart(new THREE.SphereGeometry(.052,8,6),humanMats.eye,g,ex,2.39,-.255);bodyPart(new THREE.SphereGeometry(.024,7,5),humanMats.pupil,g,ex,2.39,-.296);bodyPart(new THREE.BoxGeometry(.12,.025,.025),humanMats.hair,g,ex,2.49,-.266,0,0,ex*.8)}
  bodyPart(new THREE.BoxGeometry(.16,.025,.025),humanMats.hair,g,0,2.20,-.265);bodyPart(new THREE.SphereGeometry(.075,8,6),mats.skin,g,-.27,2.34,0);bodyPart(new THREE.SphereGeometry(.075,8,6),mats.skin,g,.27,2.34,0);
  const leftLeg=makeLimb(g,-.19,.98,0,.54,.53,cloth,true),rightLeg=makeLimb(g,.19,.98,0,.54,.53,cloth,true);
  const leftArm=makeLimb(g,-.5,1.82,0,.47,.43,isGuard?humanMats.chain:cloth),rightArm=makeLimb(g,.5,1.82,0,.47,.43,isGuard?humanMats.chain:cloth);
  leftArm.upper.rotation.z=-.1;rightArm.upper.rotation.z=.1;
  let cloak=null,weapon=null,buckler=null;
  if(isGuard){
    const helmet=bodyPart(new THREE.SphereGeometry(.35,12,7,0,Math.PI*2,0,Math.PI/2),humanMats.steel,g,0,2.43,0);helmet.scale.z=.92;bodyPart(new THREE.BoxGeometry(.07,.42,.07),humanMats.steel,g,0,2.27,.31);
    const plume=bodyPart(new THREE.BoxGeometry(.09,.48,.38),mats.red,g,0,2.78,.04,0,0,.04);
    bodyPart(new THREE.ConeGeometry(.24,.32,6),humanMats.steel,g,-.48,1.84,0,0,0,-Math.PI/2);bodyPart(new THREE.ConeGeometry(.24,.32,6),humanMats.steel,g,.48,1.84,0,0,0,Math.PI/2);
    bodyPart(new THREE.BoxGeometry(.22,.32,.16),humanMats.steel,rightArm.lower,0,-.22,0);bodyPart(new THREE.BoxGeometry(.22,.32,.16),humanMats.steel,leftArm.lower,0,-.22,0);
    const shield=bodyPart(new THREE.CylinderGeometry(.43,.43,.09,16),humanMats.steel,leftArm.lower,0,-.23,-.2,Math.PI/2);shield.scale.y=1.25;bodyPart(new THREE.BoxGeometry(.52,.12,.1),mats.red,shield,0,0,-.05);
    const spear=bodyPart(new THREE.CylinderGeometry(.035,.045,2.7,7),mats.wood,rightArm.upper,.06,-.62,-.03,0,0,-.05);bodyPart(new THREE.ConeGeometry(.09,.3,6),humanMats.steel,spear,0,-1.5,0);
  }else{
    cloak=bodyPart(cloakGeometry(),humanMats.cloak,g,0,1.34,.36);
    const hoodBack=bodyPart(new THREE.SphereGeometry(.34,12,9),humanMats.cloak,g,0,2.35,.09);hoodBack.scale.set(1.02,1.08,.72);bodyPart(new THREE.TorusGeometry(.285,.075,8,14),humanMats.cloak,g,0,2.31,-.25);
    weapon=new THREE.Group();weapon.position.set(0,-.39,-.02);rightArm.lower.add(weapon);
    bodyPart(new THREE.CylinderGeometry(.045,.045,.25,8),humanMats.leather,weapon,0,-.05,0);bodyPart(new THREE.BoxGeometry(.34,.055,.1),mats.gold,weapon,0,-.19,0);
    bodyPart(new THREE.BoxGeometry(.085,.82,.035),humanMats.steel,weapon,0,-.62,0);bodyPart(new THREE.ConeGeometry(.062,.18,4),humanMats.steel,weapon,0,-1.12,0,Math.PI/4);
    buckler=bodyPart(new THREE.CylinderGeometry(.29,.29,.09,18),humanMats.steel,leftArm.lower,0,-.24,-.18,Math.PI/2);bodyPart(new THREE.TorusGeometry(.235,.025,7,18),mats.gold,buckler,0,0,-.052,Math.PI/2);bodyPart(new THREE.SphereGeometry(.075,8,6),mats.gold,buckler,0,0,-.09);
    bodyPart(new THREE.BoxGeometry(.16,.24,.12),humanMats.leather,g,-.31,1.03,-.22);bodyPart(new THREE.BoxGeometry(.16,.24,.12),humanMats.leather,g,.31,1.03,-.22);bodyPart(new THREE.BoxGeometry(.16,.16,.08),mats.gold,g,0,1.12,-.23);
  }
  return {group:g,pelvis,torso,head,leftLeg,rightLeg,leftArm,rightArm,cloak,weapon,buckler,phase:rand(0,6)};
}
const playerRig=createHuman('spy'),playerModel=playerRig.group;world.add(playerModel);

// Patrol guards use the same human skeleton with armor and individual gait.
function makeGuard(name,path){
  const type=/Commander|captain|King tower/.test(name)?'commander':/road|Market|Abbey watch|Courtyard south/.test(name)?'scout':'sentry',rig=createHuman('guard'),g=rig.group;g.position.copy(path[0]);world.add(g);
  const baseHealth=type==='commander'?160:type==='sentry'?120:82,guard={name,type,group:g,rig,path,index:1,state:'patrol',wait:0,lastSeen:new THREE.Vector3(),lost:0,hitCooldown:0,home:path[0].clone(),moving:false,baseHealth,health:baseHealth,alive:true,stuck:0};
  if(type==='commander'){bodyPart(new THREE.TorusGeometry(.3,.055,7,12),mats.gold,g,0,2.7,0,Math.PI/2);bodyPart(new THREE.BoxGeometry(.52,.1,.12),mats.gold,g,0,1.72,-.32)}
  else if(type==='scout'){bodyPart(new THREE.TorusGeometry(.31,.035,7,14),humanMats.leather,g,0,2.5,0,Math.PI/2);g.scale.set(.94,.97,.94)}
  guards.push(guard);return guard;
}
const V=(x,z)=>new THREE.Vector3(x,0,z);
makeGuard('Gate west',[V(-5,35),V(-13,27),V(-5,24),V(-2,35)]);makeGuard('Gate east',[V(5,35),V(14,27),V(5,23),V(2,35)]);
makeGuard('Courtyard north',[V(-20,-23),V(0,-25),V(20,-23),V(0,-19)]);makeGuard('Courtyard south',[V(-20,20),V(18,19),V(19,7),V(-18,7)]);
const commander=makeGuard('Commander',[V(-8,-6),V(-7,-17),V(-21,-19),V(-22,-7)]);commander.baseHealth=170;commander.health=170;const treasuryCaptain=makeGuard('Treasury captain',[V(8,-6),V(22,-6),V(23,-21),V(9,-21)]);treasuryCaptain.baseHealth=190;treasuryCaptain.health=190;bodyPart(new THREE.TorusGeometry(.28,.07,7,12),mats.gold,treasuryCaptain.group,0,2.72,0,Math.PI/2);
makeGuard('West wall',[V(-26,22),V(-26,5),V(-25,-12),V(-25,-24)]);makeGuard('East wall',[V(26,-24),V(26,-5),V(26,17),V(24,25)]);
makeGuard('Keep',[V(-6,2),V(6,2),V(6,-13),V(-6,-13)]);makeGuard('Market',[V(-12,13),V(12,12),V(16,22),V(-16,22)]);
makeGuard('West road',[V(-45,12),V(-65,12),V(-82,12),V(-62,28)]);makeGuard('Frontier north',[V(-142,-23),V(-100,-23),V(-98,4),V(-140,4)]);makeGuard('Frontier south',[V(-142,23),V(-100,23),V(-98,8),V(-140,8)]);
makeGuard('East road',[V(45,12),V(66,12),V(84,12),V(64,28)]);makeGuard('Abbey watch',[V(96,-25),V(144,-25),V(145,20),V(100,20)]);makeGuard('Abbey inner',[V(112,-8),V(136,-8),V(136,8),V(112,8)]);
makeGuard('Royal gate',[V(-12,-104),V(12,-104),V(25,-115),V(-25,-115)]);makeGuard('Royal west',[V(-30,-120),V(-30,-160),V(-14,-164),V(-14,-118)]);makeGuard('Royal east',[V(30,-120),V(30,-160),V(14,-164),V(14,-118)]);makeGuard('King tower',[V(-8,-126),V(8,-126),V(8,-148),V(-8,-148)]);

const CAMPAIGN=[null,
  {title:'Чёрный ворон',operation:'ОПЕРАЦИЯ «ЧЁРНЫЙ ВОРОН»',description:'Полная разведывательная операция: изучите крепость, проникните внутрь, украдите планы и казну, затем выберитесь к лошади.',spawn:V(0,58),yaw:0,env:[0x0a171c,0x102126,1.18],steps:[
    ['l1_scout','Оценить гарнизон','Наблюдательная точка у южного моста'],['l1_passage','Найти тайный проход','Маленькая лазейка в западной стене'],['l1_plans','Похитить планы','Командная башня внутри крепости'],['l1_treasury','Ограбить казну','Победите капитана и откройте сундук'],['l1_escape','Уйти незамеченным','Доберитесь до лошади в южном лесу']]},
  {title:'Украденная печать',operation:'ОПЕРАЦИЯ «УКРАДЕННАЯ ПЕЧАТЬ»',description:'Пройдите по восточному тракту единого королевства, раскройте сеть курьеров в монастырском квартале и отберите печать у командира.',spawn:V(45,12),yaw:-Math.PI/2,env:[0x17150f,0x2a261b,1.28],steps:[
    ['l2_tracks','Найти след курьера','Брошенная повозка на восточном тракте'],['l2_informant','Найти тайник связного','Тайник возле ворот монастырского квартала'],['l2_roster','Похитить реестр','Реестр хранится на площади аббатства'],['l2_seal','Забрать королевскую печать','Победите командира внутри аббатства'],['l2_exit','Передать печать союзнику','Вернитесь к лагерю на восточном тракте']]},
  {title:'Тихий яд',operation:'ОПЕРАЦИЯ «ТИХИЙ ЯД»',description:'Исследуйте восточный городской квартал, склады и аббатство. Найдите формулу противоядия и уничтожьте запас яда.',spawn:V(160,45),yaw:0,env:[0x0d1a13,0x173522,1.08],steps:[
    ['l3_well','Проверить заражённый колодец','Колодец на площади монастырского квартала'],['l3_antidote','Найти противоядие','Светящийся флакон на ящике у западной стены южного склада'],['l3_formula','Украсть формулу','Записи алхимика внутри аббатства'],['l3_stock','Уничтожить запас яда','Ящики в северном складе у стены'],['l3_signal','Подать сигнал лекарям','Восточная башня общей стены королевства']]},
  {title:'Ночь осады',operation:'ОПЕРАЦИЯ «НОЧЬ ОСАДЫ»',description:'Весь западный край королевства атакован. Доберитесь до пограничной крепости, зажгите башни и закройте её ворота.',spawn:V(-75,12),yaw:Math.PI/2,env:[0x1d0d0b,0x411a16,1.34],steps:[
    ['l4_west','Зажечь северный маяк','Северо-западная башня пограничной крепости'],['l4_east','Зажечь южный маяк','Пересеките весь крепостной двор'],['l4_captain','Победить полевого капитана','Он командует атакой в центре крепости'],['l4_gate','Опустить решётку','Рычаг восточных ворот крепости'],['l4_keep','Удержать внутренний рубеж','Каменный донжон пограничного гарнизона']]},
  {title:'Последний приказ',operation:'ОПЕРАЦИЯ «ПОСЛЕДНИЙ ПРИКАЗ»',description:'Пройдите северный королевский тракт в столицу, проникните в главную башню короля и уничтожьте командование.',spawn:V(0,-78),yaw:0,env:[0x101722,0x1a2637,1.22],steps:[
    ['l5_cipher','Похитить королевский шифр','Архив западного крыла столицы'],['l5_crown','Войти в главную башню короля','Доберитесь до трона и заберите корону'],['l5_orders','Уничтожить приказ о вторжении','Восточные казармы королевской столицы'],['l5_commander','Победить главнокомандующего','Он охраняет вход в королевскую башню'],['l5_breach','Покинуть королевство','Северные ворота единой внешней стены']]}
];
const allObjectiveIds=CAMPAIGN.slice(1).flatMap(m=>m.steps.map(s=>s[0]));
const game={running:false,paused:false,view:'third',level:1,step:0,pendingLevel:0,crouched:false,sprinting:false,health:100,stamina:100,alert:0,gold:0,secrets:new Set(),completedLevels:0,enemyCount:null,objectives:Object.fromEntries(allObjectiveIds.map(id=>[id,false])),blocking:false,attackTimer:0,blockTimer:0,crawlHint:0,caught:0,startTime:0,elapsedBeforeSave:0,checkpoint:V(0,58),noiseCooldown:0,soundOn:true};
const player={pos:new THREE.Vector3(0,0,58),yaw:0,pitch:-.08,velocity:new THREE.Vector3(),radius:.48,grounded:true};
const keys={},virtualKeys={},clock=new THREE.Clock();let nearest=null,messageTimer,footstep=0,mouseBlock=false,gestureBlock=false,voiceBlockUntil=0;
const controlDown=code=>!!(keys[code]||virtualKeys[code]);
function pulseControl(code,ms=850){virtualKeys[code]=true;setTimeout(()=>{virtualKeys[code]=false},ms)}
function clearVirtualMovement(){for(const code of ['KeyW','KeyA','KeyS','KeyD','ControlLeft'])virtualKeys[code]=false}

const SAVE_KEY='kingdoms_shadow_save_v3';
const ACHIEVEMENTS={
  scout:['Глаза королевства','Разведать численность гарнизона'],firstBlood:['Первая кровь','Обезвредить первого противника'],strategist:['Государственный ум','Использовать все три направления развития'],
  diplomat:['Мир дороже золота','Добиться союза с соседним государством'],treasure:['Королевский клад','Накопить 400 золотых'],crown:['Без короны','Забрать корону из главной башни'],ghost:['Настоящая тень','Завершить кампанию без поражений']
};
const career={runs:0,bestTime:null,totalGold:0,defeats:0,decisions:0,achievements:[],unlockedPacks:[],activePack:'default'};
const strategy={treasury:180,food:70,influence:45,army:55,threat:18,history:[],resolvedLevels:{},factions:[
  {id:'iron',name:'Железные марки',relation:-18,strength:72,bias:'military',tactic:'наблюдение',reason:'оценивает границу'},
  {id:'silver',name:'Серебряная лига',relation:22,strength:48,bias:'trade',tactic:'торговля',reason:'ищет выгодный договор'},
  {id:'north',name:'Северные кланы',relation:-4,strength:61,bias:'raid',tactic:'разведка',reason:'проверяет оборону'}
]};
let loadedSave=null,pendingCouncilLevel=1,councilMandatory=false,audioCtx=null,audioMaster=null,ambientSource=null;
function safeReadSave(){try{return JSON.parse(localStorage.getItem(SAVE_KEY)||'null')}catch{return null}}
function safeWriteSave(data){try{localStorage.setItem(SAVE_KEY,JSON.stringify(data));return true}catch{return false}}
function elapsedSeconds(){return Math.max(0,(game.elapsedBeforeSave||0)+(game.startTime?(performance.now()-game.startTime)/1000:0))}
function saveProgress(){
  safeWriteSave({version:3,savedAt:new Date().toISOString(),game:{level:game.level,step:game.step,gold:game.gold,caught:game.caught,completedLevels:game.completedLevels,objectives:game.objectives,checkpoint:[game.checkpoint.x,game.checkpoint.z],elapsed:elapsedSeconds()},strategy,career});loadedSave=safeReadSave();updateContinueButton();
}
function hydratePersistentData(){
  loadedSave=safeReadSave();if(!loadedSave)return;Object.assign(career,loadedSave.career||{});if(loadedSave.strategy){for(const key of ['treasury','food','influence','army','threat','history','resolvedLevels'])if(loadedSave.strategy[key]!==undefined)strategy[key]=loadedSave.strategy[key];if(Array.isArray(loadedSave.strategy.factions))strategy.factions=loadedSave.strategy.factions}applyCosmetic(career.activePack||'default');
}
function updateContinueButton(){const button=$('#continueBtn');if(!button)return;button.classList.toggle('hidden',!loadedSave?.game)}
function unlockAchievement(id){if(!ACHIEVEMENTS[id]||career.achievements.includes(id))return;career.achievements.push(id);const toast=$('#achievementToast');toast.querySelector('b').textContent=ACHIEVEMENTS[id][0];toast.classList.remove('hidden');sfx('achievement');setTimeout(()=>toast.classList.add('hidden'),3200);saveProgress()}
function renderStatistics(){
  $('#statRuns').textContent=career.runs;$('#statBest').textContent=career.bestTime?formatTime(career.bestTime):'—';$('#statGold').textContent=career.totalGold;$('#statDefeats').textContent=career.defeats;$('#statDecisions').textContent=career.decisions;$('#statAchievements').textContent=`${career.achievements.length} / ${Object.keys(ACHIEVEMENTS).length}`;
  $('#achievementList').innerHTML=Object.entries(ACHIEVEMENTS).map(([id,[name,desc]])=>`<div class="achievement ${career.achievements.includes(id)?'unlocked':''}"><b>${career.achievements.includes(id)?'◆ ':''}${name}</b><span>${desc}</span></div>`).join('');
}
function showStatistics(){renderStatistics();$('#statistics').classList.remove('hidden');if(game.running){game.paused=true;document.exitPointerLock?.()}}
function hideStatistics(){$('#statistics').classList.add('hidden');if(game.running&&!$('#pause').classList.contains('hidden'))return;if(game.running&&!councilMandatory)game.paused=false}
function formatTime(seconds){const value=Math.round(seconds),mins=Math.floor(value/60),secs=value%60;return `${String(mins).padStart(2,'0')}:${String(secs).padStart(2,'0')}`}

function choiceCounts(){return strategy.history.reduce((a,x)=>(a[x]=(a[x]||0)+1,a),{economy:0,diplomacy:0,military:0})}
function chooseNeighborTactic(faction){
  return chooseNeighborStrategy(faction,strategy,choiceCounts());
}
function applyFactionOutcome(faction,decision){
  const result=chooseNeighborTactic(faction);faction.tactic=result.label;faction.reason=result.reason;
  if(result.tactic==='trade'){strategy.treasury+=18;strategy.food+=8;faction.relation+=3}
  if(result.tactic==='alliance'){strategy.influence+=12;faction.relation+=6;unlockAchievement('diplomat')}
  if(result.tactic==='spy'){strategy.threat+=6;strategy.treasury=Math.max(0,strategy.treasury-8)}
  if(result.tactic==='raid'){strategy.threat+=9;strategy.food=Math.max(0,strategy.food-12);faction.relation-=3}
  if(result.tactic==='siege'){strategy.threat+=15;strategy.army=Math.max(0,strategy.army-5);faction.relation-=5}
  if(decision==='diplomacy')faction.relation=Math.min(100,faction.relation+9);else if(decision==='military'&&faction.relation<0)faction.relation-=2;
  return `${faction.name}: ${result.label}, потому что ${result.reason}.`;
}
function missionModifiers(){return {initialAlert:clamp(strategy.threat-strategy.army*.18-choiceCounts().diplomacy*3,0,48),guardHealth:clamp(1+(strategy.threat-strategy.army)*.0055,.78,1.32),healthBonus:choiceCounts().economy?15:0,staminaBonus:strategy.food>70?20:0}}
function renderCouncil(){
  $('#councilTurn').textContent=`ХОД ${pendingCouncilLevel} / 5`;$('#kingdomTreasury').textContent=Math.round(strategy.treasury);$('#kingdomFood').textContent=Math.round(strategy.food);$('#kingdomInfluence').textContent=Math.round(strategy.influence);$('#kingdomArmy').textContent=Math.round(strategy.army);
  $('#factionList').innerHTML=strategy.factions.map(f=>`<div class="faction ${f.relation>25?'friendly':f.relation<0?'hostile':''}"><b>${f.name}</b><span>отношения ${f.relation>0?'+':''}${f.relation} · сила ${f.strength}</span><small>AI: ${f.tactic}. ${f.reason}.</small></div>`).join('');
  const resolved=!!strategy.resolvedLevels[pendingCouncilLevel];$$('[data-decision]').forEach(b=>{b.disabled=resolved||(!councilMandatory&&game.running);b.classList.toggle('selected',strategy.resolvedLevels[pendingCouncilLevel]===b.dataset.decision)});$('#councilContinue').disabled=councilMandatory&&!resolved;$('#councilContinue').textContent=councilMandatory?(pendingCouncilLevel===1?'Начать разведку':'Перейти к операции'):'Вернуться в игру';
  $$('.shop-item').forEach(item=>{const unlocked=career.unlockedPacks.includes(item.dataset.pack);item.classList.toggle('unlocked',unlocked);item.querySelector('button').textContent=unlocked?(career.activePack===item.dataset.pack?'Выбрано':'Надеть'):'Демо-покупка'});
}
function resolveCouncilDecision(type){
  if(strategy.resolvedLevels[pendingCouncilLevel])return;const costs={economy:()=>strategy.treasury>=40,diplomacy:()=>strategy.influence>=20,military:()=>strategy.treasury>=55};if(!costs[type]?.()){message('Недостаточно ресурсов для этого решения.',1800);return}
  if(type==='economy'){strategy.treasury-=40;strategy.food+=35}else if(type==='diplomacy'){strategy.influence-=20}else{strategy.treasury-=55;strategy.army+=25;strategy.threat=Math.max(0,strategy.threat-4)}
  strategy.history.push(type);strategy.resolvedLevels[pendingCouncilLevel]=type;career.decisions++;const reports=strategy.factions.map(f=>applyFactionOutcome(f,type));strategy.treasury=Math.max(0,strategy.treasury);strategy.food=clamp(strategy.food,0,160);strategy.influence=clamp(strategy.influence,0,120);strategy.army=clamp(strategy.army,0,140);strategy.threat=clamp(strategy.threat,0,100);
  if(new Set(strategy.history).size===3)unlockAchievement('strategist');$('#councilResult').textContent=`Решение принято. ${reports.join(' ')}`;$('#councilResult').classList.remove('hidden');sfx('objective');renderCouncil();saveProgress();
}
function showCouncil(level=game.level,mandatory=false){pendingCouncilLevel=level;councilMandatory=mandatory;if(game.running){game.paused=true;document.exitPointerLock?.()}$('#councilBrief').textContent=mandatory?'Соседние государства анализируют ваши ресурсы и прошлые решения. Выберите приоритет перед следующей операцией.':'Текущая стратегическая обстановка. Решение этого хода уже зафиксировано.';$('#councilResult').classList.add('hidden');renderCouncil();$('#council').classList.remove('hidden')}
function closeCouncil(){if(councilMandatory&&!strategy.resolvedLevels[pendingCouncilLevel])return;$('#council').classList.add('hidden');const target=pendingCouncilLevel;councilMandatory=false;if(target>1&&game.level!==target)showLevel(target);else if(game.running){const mods=missionModifiers();game.alert=Math.max(game.alert,mods.initialAlert);guards.forEach((g,i)=>{const suppressed=strategy.army>95&&i>9&&g!==treasuryCaptain&&g!==commander&&i%6===0;g.alive=!suppressed;g.group.visible=!suppressed;g.health=Math.round(g.baseHealth*mods.guardHealth)});game.enemyCount=guards.filter(g=>g.alive).length+8;game.paused=false;message(`План действует: тревога ${Math.round(game.alert)}, сила гарнизона ${Math.round(mods.guardHealth*100)}%.`,2800);saveProgress()}}
function applyCosmetic(pack){career.activePack=pack;if(pack==='raven'){humanMats.cloak.color.setHex(0x102e3f);mats.gold.color.setHex(0xd5af52)}else if(pack==='crimson'){humanMats.cloak.color.setHex(0x6b2027);mats.gold.color.setHex(0xaab1b2)}else{humanMats.cloak.color.setHex(0x122a38);mats.gold.color.setHex(0xd1a448)}}
function shopAction(pack){if(!career.unlockedPacks.includes(pack)){career.unlockedPacks.push(pack);message('Учебная демо-покупка подтверждена. Реальные деньги не списаны.',2600)}applyCosmetic(pack);renderCouncil();saveProgress()}

function initAudio(){
  if(audioCtx)return;const AudioContextClass=window.AudioContext||window.webkitAudioContext;if(!AudioContextClass)return;audioCtx=new AudioContextClass();audioMaster=audioCtx.createGain();audioMaster.gain.value=.22;audioMaster.connect(audioCtx.destination);const length=audioCtx.sampleRate*2,buffer=audioCtx.createBuffer(1,length,audioCtx.sampleRate),data=buffer.getChannelData(0);for(let i=0;i<length;i++)data[i]=(Math.random()*2-1)*.22;ambientSource=audioCtx.createBufferSource();ambientSource.buffer=buffer;ambientSource.loop=true;const filter=audioCtx.createBiquadFilter(),gain=audioCtx.createGain();filter.type='lowpass';filter.frequency.value=420;gain.gain.value=.05;ambientSource.connect(filter).connect(gain).connect(audioMaster);ambientSource.start();
}
function tone(freq,duration=.12,type='sine',volume=.12,slide=0){if(!audioCtx||!game.soundOn)return;const o=audioCtx.createOscillator(),g=audioCtx.createGain();o.type=type;o.frequency.setValueAtTime(freq,audioCtx.currentTime);if(slide)o.frequency.exponentialRampToValueAtTime(Math.max(20,freq+slide),audioCtx.currentTime+duration);g.gain.setValueAtTime(volume,audioCtx.currentTime);g.gain.exponentialRampToValueAtTime(.001,audioCtx.currentTime+duration);o.connect(g).connect(audioMaster);o.start();o.stop(audioCtx.currentTime+duration)}
function sfx(name){if(name==='attack'){tone(320,.16,'sawtooth',.08,-220)}else if(name==='block'){tone(780,.12,'square',.07,-300);setTimeout(()=>tone(1100,.08,'sine',.04),45)}else if(name==='damage'){tone(95,.22,'sawtooth',.12,-40)}else if(name==='objective'){tone(440,.18,'sine',.08,220);setTimeout(()=>tone(660,.2,'sine',.07,180),130)}else if(name==='achievement'){tone(520,.18,'triangle',.08,180);setTimeout(()=>tone(780,.28,'triangle',.08,260),160)}else if(name==='alarm'){tone(180,.45,'square',.05,40)}}
function toggleSound(){game.soundOn=!game.soundOn;initAudio();if(audioMaster)audioMaster.gain.value=game.soundOn?.22:0;$('#soundBtn').classList.toggle('active',game.soundOn);$('#soundBtn').setAttribute('aria-label',game.soundOn?'Выключить звук':'Включить звук');saveProgress()}

const aiControl={voice:false,gesture:false,recognition:null,handLandmarker:null,stream:null,lastVideoTime:-1,lastGestureAt:0,lastActionAt:0,lastVoiceIntent:'',lastVoiceAt:0};
function setAIStatus(mode,status,hint){$('#aiPanel').classList.remove('hidden');$('#aiMode').textContent=mode;$('#aiStatus').textContent=status;if(hint)$('#aiHint').textContent=hint}
function hideAIPanelIfIdle(){if(!aiControl.voice&&!aiControl.gesture)$('#aiPanel').classList.add('hidden')}
function voiceIntent(command){
  if(command.includes('стоп'))return 'stop';if(command.includes('беги'))return 'run';if(command.includes('вперед')||command.includes('иди'))return 'forward';if(command.includes('назад'))return 'backward';if(command.includes('влево')||command.includes('налево'))return 'left';if(command.includes('вправо')||command.includes('направо'))return 'right';if(command.includes('присяд')||command.includes('пригни'))return 'crouch';if(command.includes('встан'))return 'stand';if(command.includes('прыж'))return 'jump';if(command.includes('удар')||command.includes('атак'))return 'attack';if(command.includes('блок')||command.includes('защит'))return 'block';if(command.includes('действ')||command.includes('взаим')||command.includes('открой'))return 'interact';if(command.includes('камень')||command.includes('отвле'))return 'stone';if(command.includes('перв'))return 'first';if(command.includes('трет'))return 'third';return '';
}
function executeVoiceCommand(raw,isInterim=false){
  const command=raw.toLowerCase().replaceAll('ё','е').trim(),intent=voiceIntent(command),now=performance.now();if(!intent){if(!isInterim)message(`Команда не распознана: «${raw.trim()}»`,1200);return false}if(intent===aiControl.lastVoiceIntent&&now-aiControl.lastVoiceAt<1200)return true;aiControl.lastVoiceIntent=intent;aiControl.lastVoiceAt=now;setAIStatus('ГОЛОСОВОЕ УПРАВЛЕНИЕ',`⚡ ${raw.trim()}`,'Быстрый режим: команда выполняется по промежуточному результату, без ожидания длинной паузы.');
  if(intent==='stop')clearVirtualMovement();
  else if(intent==='run'){pulseControl('KeyW',1500);pulseControl('ControlLeft',1500)}
  else if(intent==='forward')pulseControl('KeyW',1100);else if(intent==='backward')pulseControl('KeyS',900);else if(intent==='left')pulseControl('KeyA',900);else if(intent==='right')pulseControl('KeyD',900);
  else if(intent==='crouch'){if(!game.crouched)toggleCrouch()}else if(intent==='stand'){if(game.crouched)toggleCrouch()}else if(intent==='jump')jump();else if(intent==='attack')attack();else if(intent==='block')voiceBlockUntil=now+1600;else if(intent==='interact')useInteraction();else if(intent==='stone')throwStone();else if(intent==='first'){if(game.view!=='first')setView()}else if(intent==='third'){if(game.view!=='third')setView()}return true;
}
function toggleVoice(){
  if(aiControl.voice){aiControl.voice=false;aiControl.recognition?.stop();$('#voiceBtn').classList.remove('active');setAIStatus('ГОЛОСОВОЕ УПРАВЛЕНИЕ','выключено');hideAIPanelIfIdle();return}
  const Recognition=window.SpeechRecognition||window.webkitSpeechRecognition;if(!Recognition){setAIStatus('ГОЛОСОВОЕ УПРАВЛЕНИЕ','не поддерживается','Откройте игру в Chrome или Edge. Клавиатура и мышь продолжают работать.');message('Этот браузер не поддерживает распознавание речи.',2400);return}
  const recognition=new Recognition();recognition.lang='ru-RU';recognition.continuous=true;recognition.interimResults=true;recognition.maxAlternatives=1;const Grammar=window.SpeechGrammarList||window.webkitSpeechGrammarList;if(Grammar){const grammar=new Grammar();grammar.addFromString('#JSGF V1.0; grammar commands; public <command> = вперед | назад | влево | вправо | стоп | беги | присядь | встань | прыжок | удар | блок | действие | камень | первое лицо | третье лицо ;',1);recognition.grammars=grammar}aiControl.recognition=recognition;aiControl.voice=true;aiControl.lastVoiceIntent='';aiControl.lastVoiceAt=0;$('#voiceBtn').classList.add('active');setAIStatus('ГОЛОСОВОЕ УПРАВЛЕНИЕ','запрос микрофона…','После разрешения скажите короткую команду: «вперёд», «удар», «блок» или «действие».');
  recognition.onstart=()=>setAIStatus('ГОЛОСОВОЕ УПРАВЛЕНИЕ','слушаю · быстрый режим','Команда выполняется сразу после распознавания ключевого слова.');
  recognition.onspeechstart=()=>setAIStatus('ГОЛОСОВОЕ УПРАВЛЕНИЕ','слышу голос…','Говорите коротко: одно действие за команду.');
  recognition.onresult=e=>{for(let i=e.resultIndex;i<e.results.length;i++){const result=e.results[i],raw=result[0].transcript;if(result.isFinal)executeVoiceCommand(raw,false);else{const handled=executeVoiceCommand(raw,true);if(!handled)setAIStatus('ГОЛОСОВОЕ УПРАВЛЕНИЕ',`… ${raw.trim()}`,'Распознаю команду без ожидания конца фразы.')}}};
  recognition.onerror=e=>{if(e.error==='not-allowed'){aiControl.voice=false;$('#voiceBtn').classList.remove('active')}setAIStatus('ГОЛОСОВОЕ УПРАВЛЕНИЕ',e.error==='not-allowed'?'нет доступа к микрофону':'ошибка распознавания')};
  recognition.onend=()=>{if(aiControl.voice)setTimeout(()=>{try{recognition.start()}catch{}},100);else hideAIPanelIfIdle()};try{recognition.start()}catch{aiControl.voice=false;$('#voiceBtn').classList.remove('active')}
}
function drawHand(landmarks){
  const canvas=$('#gestureCanvas'),ctx=canvas.getContext('2d'),links=[[0,1],[1,2],[2,3],[3,4],[0,5],[5,6],[6,7],[7,8],[5,9],[9,10],[10,11],[11,12],[9,13],[13,14],[14,15],[15,16],[13,17],[17,18],[18,19],[19,20],[0,17]];ctx.clearRect(0,0,canvas.width,canvas.height);if(!landmarks)return;ctx.strokeStyle='#d9b96e';ctx.lineWidth=2;ctx.beginPath();for(const [a,b] of links){ctx.moveTo(landmarks[a].x*canvas.width,landmarks[a].y*canvas.height);ctx.lineTo(landmarks[b].x*canvas.width,landmarks[b].y*canvas.height)}ctx.stroke();ctx.fillStyle='#ecdfad';for(const p of landmarks){ctx.beginPath();ctx.arc(p.x*canvas.width,p.y*canvas.height,3,0,Math.PI*2);ctx.fill()}
}
function classifyGesture(hand,time){
  const up=i=>hand[i].y<hand[i-2].y-.018,pose=classifyFingerState({index:up(8),middle:up(12),ring:up(16),pinky:up(20),dx:hand[0].x-hand[8].x,dy:hand[0].y-hand[8].y});gestureBlock=pose.action==='block';clearVirtualMovement();
  if(pose.action==='attack'&&time-aiControl.lastActionAt>750){attack();aiControl.lastActionAt=time}
  else if(pose.action==='forward')virtualKeys.KeyW=true;else if(pose.action==='backward')virtualKeys.KeyS=true;else if(pose.action==='left')virtualKeys.KeyA=true;else if(pose.action==='right')virtualKeys.KeyD=true;
  else if(pose.action==='interact'&&time-aiControl.lastActionAt>900){useInteraction();aiControl.lastActionAt=time}
  setAIStatus('ЖЕСТОВОЕ УПРАВЛЕНИЕ',pose.label,'Ладонь — блок · кулак — удар · указательный палец — движение · два пальца — действие');
}
async function toggleGesture(){
  if(aiControl.gesture){aiControl.gesture=false;gestureBlock=false;clearVirtualMovement();aiControl.stream?.getTracks().forEach(t=>t.stop());aiControl.stream=null;$('#gestureBtn').classList.remove('active');$('#gesturePreview').classList.add('hidden');setAIStatus('ЖЕСТОВОЕ УПРАВЛЕНИЕ','выключено');hideAIPanelIfIdle();return}
  if(!navigator.mediaDevices?.getUserMedia){setAIStatus('ЖЕСТОВОЕ УПРАВЛЕНИЕ','камера не поддерживается');return}
  $('#gestureBtn').classList.add('active');setAIStatus('ЖЕСТОВОЕ УПРАВЛЕНИЕ','загрузка модели…','Разрешите камеру. Изображение обрабатывается в вашем браузере.');
  try{
    const stream=await navigator.mediaDevices.getUserMedia({video:{width:{ideal:480},height:{ideal:320},facingMode:'user'},audio:false}),video=$('#gestureVideo');aiControl.stream=stream;video.srcObject=stream;await video.play();
    if(!aiControl.handLandmarker){const visionModule=await import('https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@latest/+esm'),vision=await visionModule.FilesetResolver.forVisionTasks('https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@latest/wasm');aiControl.handLandmarker=await visionModule.HandLandmarker.createFromOptions(vision,{baseOptions:{modelAssetPath:'https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/1/hand_landmarker.task',delegate:'GPU'},runningMode:'VIDEO',numHands:1,minHandDetectionConfidence:.55,minTrackingConfidence:.55})}
    aiControl.gesture=true;aiControl.lastVideoTime=-1;$('#gesturePreview').classList.remove('hidden');setAIStatus('ЖЕСТОВОЕ УПРАВЛЕНИЕ','покажите руку','Ладонь — блок · кулак — удар · указательный палец — движение · два пальца — действие');
  }catch(error){aiControl.gesture=false;aiControl.stream?.getTracks().forEach(t=>t.stop());aiControl.stream=null;$('#gestureBtn').classList.remove('active');setAIStatus('ЖЕСТОВОЕ УПРАВЛЕНИЕ',error?.name==='NotAllowedError'?'нет доступа к камере':'не удалось загрузить','Проверьте доступ к камере и интернет. Обычное управление продолжает работать.')}
}
function updateGesture(time){if(!aiControl.gesture||time-aiControl.lastGestureAt<70)return;const video=$('#gestureVideo');if(video.readyState<2||video.currentTime===aiControl.lastVideoTime)return;aiControl.lastGestureAt=time;aiControl.lastVideoTime=video.currentTime;try{const result=aiControl.handLandmarker.detectForVideo(video,time),hand=result.landmarks?.[0];drawHand(hand);if(hand)classifyGesture(hand,time);else{gestureBlock=false;clearVirtualMovement();setAIStatus('ЖЕСТОВОЕ УПРАВЛЕНИЕ','рука не найдена','Покажите одну руку целиком перед камерой.')}}catch{}}

function currentStepId(){return CAMPAIGN[game.level]?.steps[game.step]?.[0]}
function renderMission(){
  const mission=CAMPAIGN[game.level];if(!mission)return;$('#missionTitle').textContent=`УРОВЕНЬ ${game.level} · ${mission.title.toUpperCase()}`;$('#operationName').textContent=mission.operation;
  $$('.objective').forEach((el,i)=>{const step=mission.steps[i];el.dataset.objective=step[0];el.querySelector('b').textContent=step[1];el.querySelector('small').textContent=step[2];el.className='objective '+(i<game.step?'complete':i===game.step?'active':'locked')});updateHUD();
}
function finishStep(id,text,{gold=0,secret=null}={}){
  if(currentStepId()!==id||game.objectives[id])return;game.objectives[id]=true;if(secret)game.secrets.add(secret);game.gold+=gold;game.checkpoint.copy(player.pos);game.step++;
  if(id==='l1_scout')unlockAchievement('scout');if(id==='l5_crown')unlockAchievement('crown');if(game.gold>=400)unlockAchievement('treasure');sfx('objective');
  if(game.step>=5){game.completedLevels=Math.max(game.completedLevels,game.level);strategy.treasury+=20+Math.round(strategy.food*.12);strategy.food=Math.max(0,strategy.food-8);strategy.influence=Math.min(120,strategy.influence+4);updateHUD();message(text,2600);saveProgress();if(game.level<5)setTimeout(()=>showCouncil(game.level+1,true),1700);else setTimeout(finishGame,1700)}else{renderMission();message(text,3600);saveProgress()}
}
function resetObjectives(){for(const k of Object.keys(game.objectives))game.objectives[k]=false;game.level=1;game.step=0;game.completedLevels=0;renderMission()}
function addInteraction(level,id,x,z,label,action,radius=2.7){interactables.push({level,id,pos:V(x,z),label,action,radius})}
function addWorldInteraction(x,z,label,handler,{radius=3,repeat=false}={}){
  const interaction={pos:V(x,z),label,radius,done:false,ambient:true,action(){if(interaction.done&&!repeat)return;handler(interaction);if(!repeat)interaction.done=true;updateHUD()}};worldInteractions.push(interaction);return interaction;
}

// Level 1: the original full mission remains one continuous infiltration with no teleports.
addInteraction(1,'l1_scout',0,44,'Осмотреть цитадель',()=>{game.enemyCount=guards.filter(g=>g.alive).length+8;const scouts=guards.filter(g=>g.type==='scout').length,sentries=guards.filter(g=>g.type==='sentry').length,commanders=guards.filter(g=>g.type==='commander').length;finishStep('l1_scout',`Разведка: ${sentries} тяжёлых часовых, ${scouts} быстрых разведчиков, ${commanders} командира и резерв гарнизона.`,{secret:'гарнизон'})},3.4);
addInteraction(1,'l1_passage',-38,-4,'Исследовать маленькую лазейку',()=>finishStep('l1_passage','Лазейка ведёт внутрь. Нажмите Shift и проползите под низким потолком.',{secret:'пролом'}),3.4);
addInteraction(1,'l1_plans',-15,-13,'Похитить планы вторжения',()=>{finishStep('l1_plans','Планы раскрывают атаку на рассвете и код казны: 7–3–1.',{secret:'планы'});if(treasuryCaptain.alive){treasuryCaptain.group.position.set(13,0,-6);treasuryCaptain.state='chase';treasuryCaptain.lastSeen.copy(player.pos)}},2.9);
addInteraction(1,'l1_treasury',15,-14,'Открыть королевский сундук',()=>{if(treasuryCaptain.alive){message('Ключ у капитана казны. Сначала победите его.',1700);return}finishStep('l1_treasury','Казна опустошена: 320 золотых. Вся крепость поднята по тревоге!',{gold:320})},3.1);
addInteraction(1,'l1_escape',5,59,'Покинуть цитадель',()=>finishStep('l1_escape','Операция «Чёрный ворон» завершена. Но война только начинается.'),3.5);

// Level 2: trace the courier network and take the royal seal.
addInteraction(2,'l2_tracks',60,12,'Осмотреть брошенную повозку',()=>finishStep('l2_tracks','Следы курьера ведут к монастырским воротам.'),3.2);
addInteraction(2,'l2_informant',92,20,'Обыскать тайник связного',()=>finishStep('l2_informant','Найдена половина шифра. Вторая часть записана в реестре аббатства.'),3.1);
addInteraction(2,'l2_roster',120,20,'Похитить реестр курьеров',()=>{finishStep('l2_roster','Реестр раскрыт. Командир лично хранит королевскую печать.');if(commander.alive){commander.group.position.set(126,0,0);commander.health=Math.round(170*missionModifiers().guardHealth);commander.state='chase';commander.lastSeen.copy(player.pos)}},3.2);
addInteraction(2,'l2_seal',126,0,'Забрать королевскую печать',()=>{if(commander.alive){message('Командир всё ещё держит печать. Победите его.',1700);return}finishStep('l2_seal','Королевская печать у вас. Теперь любые приказы врага можно подделать.')},3.4);
addInteraction(2,'l2_exit',75,12,'Передать печать союзнику',()=>finishStep('l2_exit','Печать передана разведке. Следующая угроза уже обнаружена.'),3.5);

// Level 3: investigation spreads across both wings of the fortress.
addInteraction(3,'l3_well',112,0,'Взять образец воды',()=>finishStep('l3_well','В воде найден редкий болотный яд. Нужен флакон из южного склада.'),3.2);
addInteraction(3,'l3_antidote',132,22,'Забрать светящийся флакон',()=>{antidoteVial.visible=false;finishStep('l3_antidote','Противоядие найдено, но без формулы его не воспроизвести.')},3.3);
addInteraction(3,'l3_formula',126,0,'Похитить формулу алхимика',()=>finishStep('l3_formula','Формула получена. Основной запас яда спрятан у северной стены.'),3.1);
addInteraction(3,'l3_stock',145,-24,'Уничтожить ящики с ядом',()=>finishStep('l3_stock','Запас яда уничтожен. Подайте сигнал лекарям с внешней башни.'),3.2);
addInteraction(3,'l3_signal',172,-20,'Зажечь сигнальный огонь',()=>finishStep('l3_signal','Лекари получили формулу. Восточный квартал будет спасён.'),3.5);

// Level 4: a combat-heavy siege run from tower to tower.
addInteraction(4,'l4_west',-148,-25,'Зажечь северный маяк',()=>finishStep('l4_west','Северный маяк горит. Пересеките крепостной двор к южной башне.'),3.1);
addInteraction(4,'l4_east',-148,25,'Зажечь южный маяк',()=>{finishStep('l4_east','Оба маяка зажжены. Полевой капитан вышел во двор.');if(treasuryCaptain.alive){treasuryCaptain.group.position.set(-120,0,12);treasuryCaptain.health=Math.round(210*missionModifiers().guardHealth);treasuryCaptain.state='chase';treasuryCaptain.lastSeen.copy(player.pos)}},3.1);
addInteraction(4,'l4_captain',-120,12,'Снять знак полевого капитана',()=>{if(treasuryCaptain.alive){message('Полевой капитан ещё командует атакой. Победите его.',1700);return}finishStep('l4_captain','Капитан пал. Без его команд враг отступает от ворот.')},3.5);
addInteraction(4,'l4_gate',-92,0,'Опустить воротную решётку',()=>finishStep('l4_gate','Решётка опущена. Последний рубеж — донжон пограничной крепости.'),3.2);
addInteraction(4,'l4_keep',-120,4,'Удержать внутренний рубеж',()=>finishStep('l4_keep','Западная крепость выстояла. Теперь нужно уничтожить само командование врага.'),3.4);

// Level 5: final hunt through the command room, treasury and western breach.
addInteraction(5,'l5_cipher',-24,-125,'Похитить королевский шифр',()=>finishStep('l5_cipher','Шифр открывает печати главной башни короля.'),3.1);
addInteraction(5,'l5_crown',0,-144,'Забрать корону у трона',()=>finishStep('l5_crown','Вы вошли в главную башню и забрали корону. Осталось уничтожить приказ.'),3.3);
addInteraction(5,'l5_orders',24,-125,'Сжечь приказ о вторжении',()=>{finishStep('l5_orders','Приказ уничтожен. Главнокомандующий перекрыл вход в башню.');if(commander.alive){commander.group.position.set(0,0,-123);commander.health=Math.round(240*missionModifiers().guardHealth);commander.state='chase';commander.lastSeen.copy(player.pos)}},3.2);
addInteraction(5,'l5_commander',0,-123,'Забрать меч главнокомандующего',()=>{if(commander.alive){message('Главнокомандующий ещё жив. Завершите бой.',1700);return}finishStep('l5_commander','Вражеское командование уничтожено. Уходите через северные ворота.')},3.5);
addInteraction(5,'l5_breach',0,-205,'Покинуть королевство через северные ворота',()=>finishStep('l5_breach','Кампания завершена. Всё огромное королевство осталось без приказов и короны.'),4.2);

// Optional discoveries make the roads and districts useful between campaign objectives.
addWorldInteraction(-70,13,'Обыскать дорожный обоз',()=>{game.health=Math.min(100,game.health+25);game.gold+=18;message('В обозе найдены бинты и 18 золотых. Здоровье восстановлено.',2400)});
addWorldInteraction(70,10,'Взять провизию из повозки',()=>{game.stamina=100;message('Сухой паёк восстановил выносливость.',2100)});
addWorldInteraction(-132,13,'Открыть оружейный ящик',()=>{game.health=Math.min(100,game.health+35);game.stamina=100;message('Снаряжение пограничников восстановило здоровье и выносливость.',2400)});
addWorldInteraction(-120,25,'Изучить карту западной обороны',()=>{game.enemyCount=guards.filter(g=>g.alive).length;message('Карта показывает патрули, северную башню и внутренний донжон.',2700)});
addWorldInteraction(138,28,'Собрать лекарственные травы',()=>{game.health=Math.min(100,game.health+30);message('Лекарственные травы восстановили 30 здоровья.',2100)});
addWorldInteraction(141,0,'Ударить в колокол аббатства',()=>{const bell=V(141,0);for(const g of guards)if(g.alive&&g.group.position.distanceTo(bell)<65){g.state='investigate';g.lastSeen.copy(bell);g.wait=0}message('Колокол слышен во всём восточном квартале. Стража идёт на звук.',2700)},{repeat:true,radius:4});
addWorldInteraction(0,-112,'Изучить карту столицы',()=>{game.enemyCount=guards.filter(g=>g.alive).length;message('Отмечены архив, казармы, главная башня короля и северные ворота.',2800)});
addWorldInteraction(0,-118,'Напиться из королевского фонтана',()=>{game.health=Math.min(100,game.health+18);game.stamina=100;message('Вы перевели дух: здоровье и выносливость восстановлены.',2200)},{repeat:true});
addWorldInteraction(5,-147,'Обыскать тайник за троном',()=>{game.gold+=80;game.secrets.add('тайник короля');message('За троном найден тайник короля: 80 золотых и секретная переписка.',3000)}, {radius:2.8});

const objectiveMarker=addMesh(new THREE.TorusGeometry(.6,.09,8,24),new THREE.MeshBasicMaterial({color:0xe5c36f,transparent:true,opacity:.82}),0,2,0,false);objectiveMarker.rotation.x=Math.PI/2;
function activeInteractionTarget(){return interactables.find(it=>it.level===game.level&&it.id===currentStepId()&&!game.objectives[it.id])}
function updateObjectiveMarker(time){const target=activeInteractionTarget();objectiveMarker.visible=!!target&&game.running&&!game.paused;if(!target)return;objectiveMarker.position.set(target.pos.x,2.05+Math.sin(time*.004)*.28,target.pos.z);objectiveMarker.rotation.z+=.012}
function message(text,duration=4200){const el=$('#message');el.textContent=text;el.classList.add('show');clearTimeout(messageTimer);messageTimer=setTimeout(()=>el.classList.remove('show'),duration)}
function updateHUD(){
  $('#healthBar').style.width=game.health+'%';$('#staminaBar').style.width=game.stamina+'%';$('#stealthBar').style.width=game.alert+'%';$('#enemyCount').textContent=game.enemyCount??'неизвестно';$('#levelCount').textContent=`${game.level} / 5`;$('#stepCount').textContent=`${Math.min(game.step+1,5)} / 5`;$('#goldCount').textContent=game.gold;
  $('#stance').textContent=game.crouched?'ПРИГНУЛСЯ':game.sprinting?'БЕЖИТ':'СТОИТ';$('#viewMode').textContent=game.view==='first'?'ПЕРВОЕ ЛИЦО':'ТРЕТЬЕ ЛИЦО';
  const a=$('#alertText');a.textContent=game.alert>75?'ТРЕВОГА':game.alert>25?'ПОДОЗРЕНИЕ':'СКРЫТ';a.classList.toggle('alert',game.alert>25);
}

function inCrawlspace(x=player.pos.x,z=player.pos.z){return x>-39.5&&x<-27.5&&z>-5.25&&z<-2.75}
function isBlocked(x,z){if(inCrawlspace(x,z)&&!game.crouched)return true;return colliders.some(c=>x+player.radius>c.minX&&x-player.radius<c.maxX&&z+player.radius>c.minZ&&z-player.radius<c.maxZ)}
function tryMove(dx,dz){const nx=player.pos.x+dx,nz=player.pos.z+dz;if((inCrawlspace(nx,player.pos.z)||inCrawlspace(player.pos.x,nz))&&!game.crouched&&game.crawlHint<=0){message('Лаз слишком низкий. Нажмите Shift и проходите пригнувшись.',1800);game.crawlHint=2}if(!isBlocked(nx,player.pos.z))player.pos.x=nx;if(!isBlocked(player.pos.x,nz))player.pos.z=nz;player.pos.x=clamp(player.pos.x,-215,215);player.pos.z=clamp(player.pos.z,-225,105)}
function forwardVector(){return new THREE.Vector3(-Math.sin(player.yaw),0,-Math.cos(player.yaw))}
function isHidden(){return game.crouched&&bushes.some(b=>Math.hypot(player.pos.x-b.x,player.pos.z-b.z)<b.r)}
function lineBlocked(a,b){const steps=Math.ceil(a.distanceTo(b)/1.5);for(let i=1;i<steps;i++){const t=i/steps,x=THREE.MathUtils.lerp(a.x,b.x,t),z=THREE.MathUtils.lerp(a.z,b.z,t);if(colliders.some(c=>x>c.minX&&x<c.maxX&&z>c.minZ&&z<c.maxZ))return true}return false}

function guardBlocked(x,z,r=.42){return colliders.some(c=>x+r>c.minX&&x-r<c.maxX&&z+r>c.minZ&&z-r<c.maxZ)}
function moveToward(guard,target,speed,dt){
  const d=target.clone().sub(guard.group.position);d.y=0;const len=d.length();if(len<.15){poseRig(guard.rig,0,0);return true}d.normalize();const step=Math.min(speed*dt,len),nx=guard.group.position.x+d.x*step,nz=guard.group.position.z+d.z*step;let moved=false;
  if(!guardBlocked(nx,guard.group.position.z)){guard.group.position.x=nx;moved=true}if(!guardBlocked(guard.group.position.x,nz)){guard.group.position.z=nz;moved=true}
  guard.group.rotation.y=Math.atan2(d.x,d.z);if(moved){guard.stuck=0;guard.rig.phase+=speed*dt*5.4;poseRig(guard.rig,guard.rig.phase,guard.state==='chase'?.9:.58)}else{guard.stuck+=dt;poseRig(guard.rig,0,0);if(guard.stuck>1.2&&guard.state==='chase'){guard.state='investigate';guard.lastSeen.copy(guard.group.position);guard.wait=0}}
  return len<.35;
}
function guardCanSee(g){
  const eye=g.group.position.clone();eye.y=2;const target=player.pos.clone();target.y=game.crouched?.9:1.55;const to=target.clone().sub(eye),dist=to.length();
  let range=game.sprinting?20:game.crouched?11:16;range*=g.type==='scout'?1.28:g.type==='commander'?1.12:.92;if(isHidden())range=g.type==='scout'?5:3.5;if(dist>range)return false;
  const facing=new THREE.Vector3(Math.sin(g.group.rotation.y),0,Math.cos(g.group.rotation.y));const flat=to.clone().setY(0).normalize();if(facing.dot(flat)<.48&&g.state!=='chase')return false;
  return !lineBlocked(eye,target);
}
function updateGuards(dt){
  let seen=false;
  for(const g of guards){
    if(!g.alive)continue;
    g.hitCooldown-=dt;const sees=guardCanSee(g);if(sees){seen=true;g.lastSeen.copy(player.pos);g.lost=0;game.alert+=dt*(game.sprinting?55:game.crouched?22:36);if(game.alert>72)g.state='chase'}
    const patrolSpeed=g.type==='scout'?1.65:g.type==='commander'?1.1:1.25,investigateSpeed=g.type==='scout'?2.05:g.type==='commander'?1.45:1.6,chaseSpeed=g.type==='scout'?3.25:g.type==='commander'?2.45:2.72;
    if(g.state==='patrol'){if(moveToward(g,g.path[g.index],patrolSpeed,dt)){g.wait+=dt;if(g.wait>1.2){g.index=(g.index+1)%g.path.length;g.wait=0}}}
    else if(g.state==='investigate'){if(moveToward(g,g.lastSeen,investigateSpeed,dt)){g.wait+=dt;if(g.wait>3.2){g.state='patrol';g.wait=0}}}
    else if(g.state==='chase'){
      const target=sees?player.pos:g.lastSeen;moveToward(g,target,chaseSpeed,dt);if(!sees){g.lost+=dt;if(g.lost>5){g.state='investigate';g.wait=0}}
      if(g.type==='commander'&&sees)for(const ally of guards)if(ally.alive&&ally!==g&&ally.group.position.distanceTo(g.group.position)<20&&ally.state==='patrol'){ally.state='investigate';ally.lastSeen.copy(player.pos)}
      if(g.group.position.distanceTo(player.pos)<1.55&&g.hitCooldown<=0){damagePlayer(g.type==='commander'?30:g.type==='scout'?18:24,g);g.hitCooldown=g.type==='scout'?.85:1.05}
    }
  }
  if(!seen)game.alert=Math.max(0,game.alert-dt*(guards.some(g=>g.state==='chase')?7:19));game.alert=clamp(game.alert,0,100);
  if(game.alert>=99){for(const g of guards)if(g.alive&&g.group.position.distanceTo(player.pos)<28){g.state='chase';g.lastSeen.copy(player.pos)}}
}
function throwStone(){if(game.noiseCooldown>0||!game.running||game.paused)return;game.noiseCooldown=6;const target=player.pos.clone().addScaledVector(forwardVector(),13);for(const g of guards)if(g.alive&&g.group.position.distanceTo(target)<26&&g.state!=='chase'){g.state='investigate';g.lastSeen.copy(target);g.wait=0}$('#noiseHint').classList.remove('hidden');setTimeout(()=>$('#noiseHint').classList.add('hidden'),1600);message('Камень отвлёк ближайших стражников.',1800)}
function attack(){
  if(!game.running||game.paused||game.attackTimer>0||game.blocking||game.stamina<12)return;game.attackTimer=.58;game.stamina-=12;sfx('attack');const f=forwardVector();let target=null,best=2.35;
  for(const g of guards){if(!g.alive)continue;const to=g.group.position.clone().sub(player.pos),d=to.length();if(d<best&&f.dot(to.normalize())>.05){target=g;best=d}}
  if(!target){message('Удар не достиг цели.',700);return}const stealth=target.state!=='chase'&&game.alert<55,damage=stealth?110:46;target.health-=damage;target.lastSeen.copy(player.pos);target.state='chase';game.alert=Math.max(game.alert,stealth?35:82);
  if(target.health<=0){target.alive=false;target.group.visible=false;unlockAchievement('firstBlood');const boss=target===treasuryCaptain?'Капитан побеждён.':target===commander?'Командир побеждён.':stealth?'Бесшумное обезвреживание.':'Стражник обезврежен.';message(boss)}else message('Стражник ранен и зовёт помощь!');updateHUD();saveProgress();
}
function jump(){if(!game.running||game.paused||!player.grounded||game.crouched||inCrawlspace()){message(inCrawlspace()?'В лазе невозможно прыгнуть.':'Сначала встаньте.',900);return}player.velocity.y=5.4;player.grounded=false;game.stamina=Math.max(0,game.stamina-8)}
function damagePlayer(n,guard){
  if(game.blocking&&game.stamina>=12){game.stamina-=12;if(guard){guard.hitCooldown=1.8;guard.state='investigate';guard.lastSeen.copy(player.pos)}message('Удар отражён баклером!',900);sfx('block');n=3}
  else sfx('damage');game.health=clamp(game.health-n,0,100);$('#damage').classList.add('flash');setTimeout(()=>$('#damage').classList.remove('flash'),180);updateHUD();if(game.health<=0)caught()
}
function caught(){game.running=false;game.paused=true;game.caught++;career.defeats++;sfx('alarm');document.exitPointerLock?.();$('#caught').classList.remove('hidden');saveProgress()}
function lockPointer(){try{const p=canvas.requestPointerLock?.();if(p?.catch)p.catch(()=>{})}catch{}}
function retry(){game.health=100;game.stamina=100;game.alert=0;game.blocking=false;player.pos.copy(game.checkpoint);player.pos.y=0;player.velocity.y=0;player.grounded=true;guards.forEach(g=>{if(!g.alive)return;g.group.position.copy(g.home);g.state='patrol';g.index=1;g.wait=0});$('#caught').classList.add('hidden');game.paused=false;game.running=true;updateHUD();message('Вы вернулись к последней безопасной точке. Кликните по миру для управления камерой.')}

function updatePlayer(dt,time){
  if(!game.running||game.paused)return;let mx=0,mz=0;if(controlDown('KeyW')||controlDown('ArrowUp'))mz+=1;if(controlDown('KeyS')||controlDown('ArrowDown'))mz-=1;if(controlDown('KeyA')||controlDown('ArrowLeft'))mx-=1;if(controlDown('KeyD')||controlDown('ArrowRight'))mx+=1;
  game.blocking=!!(mouseBlock||keys.KeyR||gestureBlock||performance.now()<voiceBlockUntil);game.sprinting=!!(controlDown('ControlLeft')||controlDown('ControlRight'))&&!game.crouched&&(mx||mz)&&game.stamina>4;const speed=game.crouched?1.85:game.sprinting?6.3:3.8;
  if(mx||mz){const f=forwardVector(),r=new THREE.Vector3(Math.cos(player.yaw),0,-Math.sin(player.yaw)),move=f.multiplyScalar(mz).add(r.multiplyScalar(mx)).normalize();tryMove(move.x*speed*dt,move.z*speed*dt);playerModel.rotation.y=player.yaw;footstep+=dt*speed;if(footstep>.85){footstep=0;if(game.sprinting)for(const g of guards)if(g.alive&&g.group.position.distanceTo(player.pos)<12&&g.state==='patrol'){g.state='investigate';g.lastSeen.copy(player.pos)}}playerRig.phase+=dt*speed*5.2;poseRig(playerRig,playerRig.phase,game.crouched?.42:game.sprinting?.95:.68)}else poseRig(playerRig,0,0);
  player.velocity.y-=16*dt;player.pos.y+=player.velocity.y*dt;if(player.pos.y<=0){player.pos.y=0;player.velocity.y=0;player.grounded=true}
  game.attackTimer=Math.max(0,game.attackTimer-dt);game.crawlHint=Math.max(0,game.crawlHint-dt);game.noiseCooldown=Math.max(0,game.noiseCooldown-dt);
  if(game.blocking){game.stamina=Math.max(0,game.stamina-dt*13);if(game.stamina<=0)game.blocking=false}else if(game.sprinting)game.stamina=Math.max(0,game.stamina-dt*16);else game.stamina=Math.min(100,game.stamina+dt*18);
  playerRig.leftArm.upper.rotation.z=-.1;playerRig.rightArm.upper.rotation.z=.1;playerRig.leftArm.lower.rotation.z=0;playerRig.rightArm.lower.rotation.z=0;playerRig.torso.rotation.y=0;
  let combatLunge=0;if(game.attackTimer>0){const p=1-game.attackTimer/.58,slash=Math.sin(Math.PI*p);playerRig.torso.rotation.y=-.42+p*.84;playerRig.rightArm.upper.rotation.x=.38+slash*1.08;playerRig.rightArm.upper.rotation.z=.78-p*1.48;playerRig.rightArm.lower.rotation.x=-.45-slash*.25;playerRig.leftArm.upper.rotation.x=.62;playerRig.leftArm.upper.rotation.z=-.38;combatLunge=slash*.32}else if(game.blocking){playerRig.torso.rotation.y=-.16;playerRig.leftArm.upper.rotation.x=1.30;playerRig.leftArm.upper.rotation.z=-.43;playerRig.leftArm.lower.rotation.x=-.55;playerRig.rightArm.upper.rotation.x=1.05;playerRig.rightArm.upper.rotation.z=.52;playerRig.rightArm.lower.rotation.x=-.38}
  playerModel.position.copy(player.pos).addScaledVector(forwardVector(),combatLunge);playerModel.position.y+=game.crouched?-.22:0;playerModel.scale.y=THREE.MathUtils.lerp(playerModel.scale.y,game.crouched?.76:1,.15);playerRig.torso.rotation.x=THREE.MathUtils.lerp(playerRig.torso.rotation.x,game.crouched?.24:0,.16);
}
function updateCamera(){
  const f=forwardVector();if(game.view==='first'){playerModel.visible=false;camera.position.copy(player.pos).add(new THREE.Vector3(0,game.crouched?1.08:1.72,0));const look=camera.position.clone().add(f.multiplyScalar(Math.cos(player.pitch))).add(new THREE.Vector3(0,Math.sin(player.pitch),0));camera.lookAt(look)}
  else{playerModel.visible=true;const focus=player.pos.clone().add(new THREE.Vector3(0,game.crouched?1:1.45,0));const desired=focus.clone().addScaledVector(f,-5.8).add(new THREE.Vector3(0,3.05+player.pitch*2.2,0));camera.position.lerp(desired,.16);camera.lookAt(focus.clone().addScaledVector(f,2.2))}
}
function updateInteraction(){
  nearest=null;let best=Infinity;const active=activeInteractionTarget();if(active){const d=active.pos.distanceTo(player.pos);if(d<active.radius){nearest=active;best=d}}
  if(!nearest)for(const interaction of worldInteractions){if(interaction.done)continue;const d=interaction.pos.distanceTo(player.pos);if(d<interaction.radius&&d<best){nearest=interaction;best=d}}
  const ui=$('#interaction');if(nearest){ui.classList.remove('hidden');ui.querySelector('span').textContent=nearest.label}else ui.classList.add('hidden');
}
function useInteraction(){if(nearest)nearest.action()}
function updateLocation(){
  const x=player.pos.x,z=player.pos.z;let t='КОРОЛЕВСКИЙ ТРАКТ';
  if(z>68)t='ЗЕМЛИ ЗА ЮЖНОЙ СТЕНОЙ';
  else if(z>42)t='ЮЖНЫЕ ПОЛЯ';
  else if(x<-86&&Math.abs(z)<38)t='ЗАПАДНАЯ ПОГРАНИЧНАЯ КРЕПОСТЬ';
  else if(x>86&&Math.abs(z)<38)t='МОНАСТЫРСКИЙ ГОРОД';
  else if(z<-198)t='СЕВЕРНЫЕ ВОРОТА КОРОЛЕВСТВА';
  else if(z<-124&&Math.abs(x)<14)t='ГЛАВНАЯ БАШНЯ КОРОЛЯ';
  else if(z<-94&&Math.abs(x)<42)t='КОРОЛЕВСКАЯ СТОЛИЦА';
  else if(z<-38)t='СЕВЕРНЫЙ КОРОЛЕВСКИЙ ТРАКТ';
  else if(Math.abs(x)<34&&Math.abs(z)<34)t='ЦЕНТРАЛЬНАЯ ЦИТАДЕЛЬ';
  else if(x<0)t='ЗАПАДНЫЕ УЛИЦЫ';
  else t='ВОСТОЧНЫЕ УЛИЦЫ';
  $('#location b').textContent=t;
}
function updateMinimap(){
  const c=$('#minimap'),ctx=c.getContext('2d'),scale=c.width/440,cx=x=>(x+220)*scale,cz=z=>(z+270)*scale;
  ctx.clearRect(0,0,c.width,c.height);ctx.fillStyle='#091114ed';ctx.fillRect(0,0,c.width,c.height);
  ctx.fillStyle='#273128';ctx.fillRect(cx(-180),cz(-198),360*scale,266*scale);
  ctx.strokeStyle='#75807a';ctx.lineWidth=2;ctx.strokeRect(cx(-180),cz(-198),360*scale,266*scale);
  ctx.strokeStyle='#6d6855';ctx.lineWidth=3;ctx.beginPath();ctx.moveTo(cx(-165),cz(12));ctx.lineTo(cx(165),cz(12));ctx.moveTo(cx(0),cz(65));ctx.lineTo(cx(0),cz(-210));ctx.stroke();
  ctx.fillStyle='#39413e';for(const [x,z,w,d] of [[0,0,60,60],[-120,0,64,66],[120,0,64,68],[0,-135,76,74]])ctx.fillRect(cx(x-w/2),cz(z-d/2),w*scale,d*scale);
  ctx.fillStyle='#1f2625';for(const [x,z,w,d] of [[-15,-13,13,10],[15,-14,13,12],[0,-5,10,13],[-120,-4,16,13],[126,0,22,24],[-24,-135,14,16],[24,-135,14,16],[0,-139,24,26]])ctx.fillRect(cx(x-w/2),cz(z-d/2),w*scale,d*scale);
  if(game.enemyCount!==null){ctx.fillStyle='#b64d45';for(const g of guards){if(!g.alive)continue;ctx.beginPath();ctx.arc(cx(g.group.position.x),cz(g.group.position.z),1.8,0,7);ctx.fill()}}
  ctx.save();ctx.translate(cx(player.pos.x),cz(player.pos.z));ctx.rotate(-player.yaw);ctx.fillStyle='#f0d47f';ctx.beginPath();ctx.moveTo(0,-5);ctx.lineTo(3.6,4);ctx.lineTo(-3.6,4);ctx.closePath();ctx.fill();ctx.restore();
  const target=activeInteractionTarget();if(target){ctx.strokeStyle='#f1c65f';ctx.lineWidth=2;ctx.beginPath();ctx.arc(cx(target.pos.x),cz(target.pos.z),5,0,Math.PI*2);ctx.stroke();ctx.fillStyle='#f1c65f';ctx.beginPath();ctx.arc(cx(target.pos.x),cz(target.pos.z),2,0,Math.PI*2);ctx.fill()}
  ctx.strokeStyle='#ffffff18';ctx.beginPath();ctx.arc(cx(player.pos.x),cz(player.pos.z),18*scale,0,7);ctx.stroke();
}

function setView(){game.view=game.view==='third'?'first':'third';updateHUD();message(game.view==='first'?'Вид от первого лица':'Вид от третьего лица',1200)}
function toggleCrouch(){if(game.crouched&&inCrawlspace()){message('Слишком низко: здесь можно двигаться только пригнувшись.',1300);return}game.crouched=!game.crouched;updateHUD();message(game.crouched?'Вы пригнулись и двигаетесь тише':'Вы встали',900)}
function showLevel(number){const level=CAMPAIGN[number];if(!level)return;game.pendingLevel=number;game.paused=true;document.exitPointerLock?.();$('#levelKicker').textContent=`УРОВЕНЬ ${number} ИЗ 5`;$('#levelTitle').textContent=level.title;$('#levelDescription').textContent=level.description;$('#levelCard').classList.remove('hidden')}
function beginLevel(number){
  const level=CAMPAIGN[number],mods=missionModifiers();game.level=number;game.step=0;game.pendingLevel=0;game.paused=false;game.crouched=false;game.blocking=false;game.alert=Math.max(number===4?42:number===5?24:0,mods.initialAlert);game.health=100;game.stamina=100;player.pos.copy(level.spawn);player.pos.y=0;player.velocity.set(0,0,0);player.grounded=true;player.yaw=level.yaw;game.checkpoint.copy(level.spawn);
  scene.background.setHex(level.env[0]);scene.fog.color.setHex(level.env[1]);renderer.toneMappingExposure=level.env[2];rain.material.opacity=number===3?.24:number===4?.58:.42;
  guards.forEach((g,i)=>{const suppressed=strategy.army>95&&i>9&&g!==treasuryCaptain&&g!==commander&&i%6===0;g.group.position.copy(g.home);g.group.visible=!suppressed;g.alive=!suppressed;g.health=Math.round(g.baseHealth*mods.guardHealth);g.state='patrol';g.index=1;g.wait=0;g.stuck=0;g.lastSeen.copy(player.pos)});game.enemyCount=guards.filter(g=>g.alive).length+8;
  if(number===3)antidoteVial.visible=true;$('#levelCard').classList.add('hidden');renderMission();message(`Уровень ${number}: ${level.title}. AI-угроза ${Math.round(strategy.threat)}; сила гарнизона ${Math.round(mods.guardHealth*100)}%.`,4800);saveProgress();
}
function startBriefing(){$('#start').classList.add('hidden');$('#briefing').classList.remove('hidden')}
function startGame(){
  initAudio();$('#briefing').classList.add('hidden');$('#pause').classList.add('hidden');$('#ending').classList.add('hidden');$('#start').classList.add('hidden');$('#hud').classList.remove('hidden');game.running=true;game.paused=false;game.startTime=performance.now();renderMission();message('Сначала примите решение на Королевском совете, затем начинайте разведку.',5200);updateHUD();setTimeout(()=>showCouncil(1,true),350);
}
function resetStrategyCampaign(){strategy.treasury=180;strategy.food=70;strategy.influence=45;strategy.army=55;strategy.threat=18;strategy.history=[];strategy.resolvedLevels={};strategy.factions=[{id:'iron',name:'Железные марки',relation:-18,strength:72,bias:'military',tactic:'наблюдение',reason:'оценивает границу'},{id:'silver',name:'Серебряная лига',relation:22,strength:48,bias:'trade',tactic:'торговля',reason:'ищет выгодный договор'},{id:'north',name:'Северные кланы',relation:-4,strength:61,bias:'raid',tactic:'разведка',reason:'проверяет оборону'}]}
function resetGame(){
  resetStrategyCampaign();game.view='third';game.level=1;game.step=0;game.pendingLevel=0;game.crouched=false;game.health=100;game.stamina=100;game.alert=0;game.gold=0;game.secrets.clear();game.enemyCount=null;game.caught=0;game.blocking=false;game.attackTimer=0;game.elapsedBeforeSave=0;game.checkpoint.set(0,0,58);player.pos.set(0,0,58);player.velocity.set(0,0,0);player.grounded=true;player.yaw=0;player.pitch=-.08;scene.background.setHex(CAMPAIGN[1].env[0]);scene.fog.color.setHex(CAMPAIGN[1].env[1]);renderer.toneMappingExposure=CAMPAIGN[1].env[2];rain.material.opacity=.42;antidoteVial.visible=true;worldInteractions.forEach(interaction=>interaction.done=false);resetObjectives();guards.forEach(g=>{g.group.position.copy(g.home);g.group.visible=true;g.alive=true;g.health=g.baseHealth;g.state='patrol';g.index=1;g.wait=0;g.stuck=0});startGame();
}
function continueSavedGame(){
  if(!loadedSave?.game)return;hydratePersistentData();const saved=loadedSave.game,level=CAMPAIGN[saved.level]||CAMPAIGN[1];game.level=saved.level||1;game.step=clamp(saved.step||0,0,5);game.gold=saved.gold||0;game.caught=saved.caught||0;game.completedLevels=saved.completedLevels||0;game.elapsedBeforeSave=saved.elapsed||0;game.startTime=performance.now();game.health=100;game.stamina=100;game.alert=0;game.running=true;game.paused=false;game.enemyCount=guards.length+8;Object.assign(game.objectives,saved.objectives||{});antidoteVial.visible=!game.objectives.l3_antidote;const checkpoint=saved.checkpoint||[level.spawn.x,level.spawn.z];game.checkpoint.set(checkpoint[0],0,checkpoint[1]);player.pos.copy(game.checkpoint);player.velocity.set(0,0,0);player.grounded=true;player.yaw=level.yaw;scene.background.setHex(level.env[0]);scene.fog.color.setHex(level.env[1]);renderer.toneMappingExposure=level.env[2];guards.forEach(g=>{g.group.position.copy(g.home);g.group.visible=true;g.alive=true;g.health=g.baseHealth*missionModifiers().guardHealth;g.state='patrol';g.index=1;g.wait=0;g.stuck=0});initAudio();$('#start').classList.add('hidden');$('#briefing').classList.add('hidden');$('#ending').classList.add('hidden');$('#hud').classList.remove('hidden');renderMission();updateHUD();message(`Сохранение загружено: уровень ${game.level}, этап ${Math.min(game.step+1,5)}.`,3000);if(game.step>=5&&game.level<5)setTimeout(()=>showCouncil(game.level+1,true),400)
}
function pauseGame(){if(!game.running)return;game.paused=true;document.exitPointerLock?.();$('#pause').classList.remove('hidden')}
function resumeGame(){$('#pause').classList.add('hidden');game.paused=false;message('Кликните по миру для управления камерой.',1400)}
function finishGame(){
  const seconds=Math.round(elapsedSeconds()),rank=game.caught===0?'S':game.caught<3?'A':'B';game.running=false;game.paused=true;career.runs++;career.totalGold+=game.gold;career.bestTime=career.bestTime===null?seconds:Math.min(career.bestTime,seconds);if(game.caught===0)unlockAchievement('ghost');document.exitPointerLock?.();$('#hud').classList.add('hidden');$('#ending').classList.remove('hidden');$('#resultSecrets').textContent='5/5';$('#resultGold').textContent=game.gold;$('#resultTime').textContent=formatTime(seconds);$('#resultRank').textContent=rank;$('#endingText').textContent=`Все пять больших операций завершены. Вы вынесли ${game.gold} золотых, сорвали осаду, спасли город от яда и лишили врага короны и командования.`;$('#resultStrategy').textContent=`Королевство: казна ${Math.round(strategy.treasury)}, продовольствие ${Math.round(strategy.food)}, влияние ${Math.round(strategy.influence)}, армия ${Math.round(strategy.army)}. Принято стратегических решений: ${strategy.history.length}.`;saveProgress()
}

$('#startBtn').addEventListener('click',()=>{initAudio();startBriefing()});$('#continueBtn').addEventListener('click',continueSavedGame);$('#statsBtn').addEventListener('click',showStatistics);$('#closeBriefing').addEventListener('click',()=>{$('#briefing').classList.add('hidden');$('#start').classList.remove('hidden')});$('#deployBtn').addEventListener('click',resetGame);$('#menuBtn').addEventListener('click',pauseGame);$('#voiceBtn').addEventListener('click',toggleVoice);$('#gestureBtn').addEventListener('click',toggleGesture);$('#soundBtn').addEventListener('click',toggleSound);$('#councilBtn').addEventListener('click',()=>showCouncil(game.level,false));$('#resumeBtn').addEventListener('click',resumeGame);$('#restartBtn').addEventListener('click',resetGame);$('#retryBtn').addEventListener('click',retry);$('#againBtn').addEventListener('click',resetGame);$('#levelContinue').addEventListener('click',()=>beginLevel(game.pendingLevel));
$('#closeCouncil').addEventListener('click',closeCouncil);$('#councilContinue').addEventListener('click',closeCouncil);$$('[data-decision]').forEach(button=>button.addEventListener('click',()=>resolveCouncilDecision(button.dataset.decision)));$$('.shop-item').forEach(item=>item.querySelector('button').addEventListener('click',()=>shopAction(item.dataset.pack)));
$('#closeStats').addEventListener('click',hideStatistics);$('#pauseCouncilBtn').addEventListener('click',()=>{$('#pause').classList.add('hidden');showCouncil(game.level,false)});$('#pauseStatsBtn').addEventListener('click',()=>{$('#pause').classList.add('hidden');showStatistics()});$('#clearSaveBtn').addEventListener('click',()=>{try{localStorage.removeItem(SAVE_KEY)}catch{}loadedSave=null;Object.assign(career,{runs:0,bestTime:null,totalGold:0,defeats:0,decisions:0,achievements:[],unlockedPacks:[],activePack:'default'});applyCosmetic('default');renderStatistics();updateContinueButton();message('Сохранение и статистика удалены.',1800)});
canvas.addEventListener('click',()=>{if(game.running&&!game.paused&&document.pointerLockElement!==canvas)lockPointer()});canvas.addEventListener('mousedown',e=>{if(document.pointerLockElement!==canvas||!game.running||game.paused)return;if(e.button===0)attack();if(e.button===2)mouseBlock=true});canvas.addEventListener('mouseup',e=>{if(e.button===2)mouseBlock=false});canvas.addEventListener('contextmenu',e=>e.preventDefault());
addEventListener('mousemove',e=>{if(!game.running||game.paused||document.pointerLockElement!==canvas)return;player.yaw-=e.movementX*.0023;player.pitch=clamp(player.pitch-e.movementY*.0018,-.7,.55)});
addEventListener('keydown',e=>{keys[e.code]=true;if(!game.running||game.paused)return;if((e.code==='ShiftLeft'||e.code==='ShiftRight')&&!e.repeat)toggleCrouch();if(e.code==='Space'&&!e.repeat){e.preventDefault();jump()}if(e.code==='KeyV'&&!e.repeat)setView();if(e.code==='KeyE'&&!e.repeat)useInteraction();if(e.code==='KeyG'&&!e.repeat)throwStone();if(e.code==='KeyF'&&!e.repeat)attack();if(e.code==='KeyR')game.blocking=true;if(e.code==='Escape')pauseGame()});addEventListener('keyup',e=>{keys[e.code]=false;if(e.code==='KeyR')game.blocking=false});

function resize(){renderer.setSize(innerWidth,innerHeight,false);camera.aspect=innerWidth/innerHeight;camera.updateProjectionMatrix()}addEventListener('resize',resize);resize();
hydratePersistentData();updateContinueButton();renderStatistics();
let minimapTimer=0,uiTimer=0;
function loop(time){
  const dt=Math.min(clock.getDelta(),.05);updateGesture(time);updateObjectiveMarker(time);if(game.running&&!game.paused){updatePlayer(dt,time);updateGuards(dt);updateInteraction();updateCamera();uiTimer+=dt;minimapTimer+=dt;if(uiTimer>.12){updateHUD();updateLocation();uiTimer=0}if(minimapTimer>.18){updateMinimap();minimapTimer=0}}
  else if(!game.running){camera.position.lerp(new THREE.Vector3(48,42,64),.02);camera.lookAt(0,0,0)}
  const rp=rain.geometry.attributes.position.array;for(let i=1;i<rp.length;i+=3){rp[i]-=dt*22;if(rp[i]<0)rp[i]=55}rain.geometry.attributes.position.needsUpdate=true;
  torches.forEach(t=>{const f=.82+Math.sin(time*.011+t.phase)*.14+Math.random()*.08;t.flame.scale.setScalar(f);t.light.intensity=3.9+f*1.2});
  renderer.render(scene,camera);requestAnimationFrame(loop)
}requestAnimationFrame(loop);
