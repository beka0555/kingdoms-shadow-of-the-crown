# Architecture

## Компоненты

```mermaid
flowchart LR
    User[Игрок] --> UI[HTML/CSS интерфейс]
    User --> Input[Клавиатура, мышь, голос, камера]
    Input --> Gesture[MediaPipe Hand Landmarker]
    Input --> Speech[Web Speech API]
    UI --> Logic[Game Logic]
    Gesture --> Logic
    Speech --> Logic
    Logic --> GuardAI[State AI охраны]
    Logic --> StrategyAI[Utility AI государств]
    Logic --> World[Three.js 3D World]
    Logic --> Storage[localStorage]
    Storage --> Result[Прогресс, статистика, достижения]
    StrategyAI --> Result
    GuardAI --> Result
```

## Слои

1. Interface: `index.html`, `assets/style.css`.
2. Game Logic: кампания, бой, задачи, ресурсы и сохранение в `assets/game.js`.
3. AI Module: чистые функции Utility AI и жестов в `assets/ai-core.js`; поведенческие состояния NPC в `assets/game.js`.
4. Rendering: локальная копия Three.js и процедурная сцена.
5. Data/Storage: JSON-сохранение `kingdoms_shadow_save_v3` в `localStorage`.
6. Result: экран статистики, достижения, ранг и JSON-отчёт AI-тестов.

## Потоки AI

### Utility AI государств

Input: казна, еда, армия, отношения, специализация государства, история решений.  
Processing: вычисление полезности пяти тактик и выбор максимального значения.  
Output: торговля, союз, шпионаж, рейд или осада.  
Game Logic: изменяются ресурсы, угроза, здоровье и часть состава гарнизона.

### Computer Vision

Input: видеокадр с камеры.  
Processing: MediaPipe определяет 21 ориентир кисти; классификатор анализирует поднятые пальцы и направление.  
Output: блок, атака, движение или взаимодействие.  
Game Logic: действие выполняется тем же контроллером, что и клавиатурный ввод.

### State AI охраны

Input: дистанция, угол обзора, препятствия, шум, тревога, последняя позиция.  
Processing: переходы patrol, investigate и chase.  
Output: маршрут, поиск, преследование или атака.  
Game Logic: меняются здоровье игрока, тревога и состояние миссии.

## Приватность

Код не записывает видеопоток и не загружает кадры. Сохранение остаётся в браузере. Web Speech API может использовать сервис распознавания поставщика браузера; интерфейс сообщает пользователю о запросе микрофона.

