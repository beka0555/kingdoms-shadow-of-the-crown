# Комплект документации лабораторных работ 8–15

Проект: **Kingdoms: Shadow of the Crown**  
Дисциплина: **Управление IT-проектами**  
Основной разработчик: **Ракымжанов Бекзат, ИС-34**  
Участник 2: **ФИО требуется указать до создания командного GitHub-репозитория**

## Документы

| Неделя | Результат | Файл |
|---|---|---|
| 8 | Project Charter и концепция | `PROJECT_CHARTER.md`, `GAME_CONCEPT.md`, `COMMERCIALIZATION.md` |
| 9 | Требования, User Stories, MoSCoW, UI/UX | `REQUIREMENTS.md` |
| 10 | WBS, Kanban, риски, архитектура | `PROJECT_PLAN.md`, `ARCHITECTURE.md` |
| 11 | MVP 1 | рабочая браузерная игра в корне репозитория |
| 12 | AI Integration | `AI_MODULE.md`, `AI_TEST_RESULTS.md`, `tests/ai-tests.html` |
| 13 | Beta | пять уровней, стратегия, звук, статистика и достижения |
| 14 | Testing | `TEST_CASES.md`, `BUG_REPORT.md`, `USER_TESTING.md`, `PLAN_VS_ACTUAL.md` |
| 15 | Final Release | `DEMO_AND_DEFENSE.md`, презентация в папке `presentation` |

## Внешние подтверждения, которые нельзя заменять сгенерированным текстом

1. ФИО второго студента и его реальные коммиты.
2. Добавление преподавателя в Private GitHub.
3. Подписи или ответы минимум трёх тестировщиков вне команды.
4. Ссылка на опубликованную страницу itch.io после ручной загрузки владельцем аккаунта.

